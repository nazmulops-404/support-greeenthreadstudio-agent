export type PageId =
  | 'home'
  | 'about'
  | 'prototypes'
  | 'journal'
  | 'trend-watch'
  | 'contact'
  | 'submit-idea'
  | 'my-submissions'
  | 'admin';

export type SubmissionCategory =
  | 'reclaimed_fabrics'
  | 'natural_fibers'
  | 'circular_design'
  | 'dyeing_finishing'
  | 'other';

export type SubmissionStatus =
  | 'received'
  | 'under_review'
  | 'prototype_evaluation'
  | 'archived';

export interface IdeaSubmission {
  id: string;
  name: string;
  email: string;
  title: string;
  category: SubmissionCategory;
  description: string;
  status: SubmissionStatus;
  ownerId?: string | null;
  claimToken: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PrototypeItem {
  id: string;
  code: string; // e.g. "GT-P01"
  name: string;
  category: 'bags' | 'accessories' | 'materials';
  categoryLabel: string;
  stage: 'Pattern Testing' | 'Sewing Trials' | 'Loom Setup' | 'Concept Specification';
  developmentStatus: string;
  shortDescription: string;
  fullDescription: string;
  fiberComposition: string;
  weaveStructure: string;
  dimensionsEstimated: string;
  primaryImage: string;
  secondaryDetails: {
    label: string;
    value: string;
  }[];
  researchObjectives: string[];
  honestLimitation: string;
}

export interface JournalArticle {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  image?: string;
  abstract: string;
  contentParagraphs: {
    type: 'paragraph' | 'heading' | 'pullquote' | 'footnote';
    text: string;
  }[];
  keywords: string[];
}

export interface TrendWatchItem {
  id: string;
  title: string;
  organization: string;
  publicationDate: string;
  summary: string;
  sourceUrl: string;
  isVerifiedSource: boolean;
  editorialNote: string;
  focusArea: string;
}
