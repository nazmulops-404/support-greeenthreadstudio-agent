import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider, isFirebaseConfigured, checkIsAdmin } from '../lib/firebase';

export type AuthModalMode = 'signin' | 'signup' | 'forgot';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  loading: boolean;
  isConfigured: boolean;
  authModalOpen: boolean;
  authModalMode: AuthModalMode;
  openAuthModal: (mode?: AuthModalMode) => void;
  closeAuthModal: () => void;
  setAuthModalMode: (mode: AuthModalMode) => void;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, displayName?: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('signin');

  useEffect(() => {
    if (!auth || !isFirebaseConfigured) {
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const adminStatus = await checkIsAdmin(currentUser);
        setIsAdmin(adminStatus);
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAuthModal = (mode: AuthModalMode = 'signin') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
  };

  const ensureAuth = () => {
    if (!auth || !isFirebaseConfigured) {
      throw new Error(
        'Firebase configuration is missing. Please set your VITE_FIREBASE_* environment variables in .env or your Vercel deployment settings.'
      );
    }
    return auth;
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const firebaseAuth = ensureAuth();
    await signInWithEmailAndPassword(firebaseAuth, email.trim(), pass);
  };

  const signUpWithEmail = async (email: string, pass: string, displayName?: string) => {
    const firebaseAuth = ensureAuth();
    const credential = await createUserWithEmailAndPassword(firebaseAuth, email.trim(), pass);
    if (displayName && displayName.trim()) {
      await updateProfile(credential.user, { displayName: displayName.trim() });
      setUser({ ...credential.user, displayName: displayName.trim() });
    }
  };

  const signInWithGoogle = async () => {
    const firebaseAuth = ensureAuth();
    if (!googleProvider) {
      throw new Error('Google Auth provider is not initialized.');
    }
    await signInWithPopup(firebaseAuth, googleProvider);
  };

  const sendPasswordReset = async (email: string) => {
    const firebaseAuth = ensureAuth();
    await sendPasswordResetEmail(firebaseAuth, email.trim());
  };

  const logout = async () => {
    if (!auth) return;
    await signOut(auth);
    setIsAdmin(false);
  };

  const value = useMemo(
    () => ({
      user,
      isAdmin,
      loading,
      isConfigured: isFirebaseConfigured,
      authModalOpen,
      authModalMode,
      openAuthModal,
      closeAuthModal,
      setAuthModalMode,
      signInWithEmail,
      signUpWithEmail,
      signInWithGoogle,
      sendPasswordReset,
      logout,
    }),
    [user, isAdmin, loading, authModalOpen, authModalMode]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
