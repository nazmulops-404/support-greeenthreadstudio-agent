import React from 'react';
import { PageId } from '../types';
import { TextileImage } from '../components/TextileImage';
import { Microscope, Sparkles, Scale, BookOpen, Compass, CheckCircle2, AlertCircle } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-20 lg:space-y-24">
      
      {/* Editorial Header */}
      <div className="max-w-3xl space-y-4">
        <div className="flex items-center gap-4">
          <img
            src="/images/logo.jpg"
            alt="GreenThread Studio Inc. Logo"
            className="h-14 w-14 sm:h-16 sm:w-16 rounded-full object-contain bg-white border border-[#14532D]/20 p-1 shadow-xs shrink-0"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/assets/aistudio/iZqx5jgZ2fFL5zTQa_i632ncu-ulOcxgsElkkvHaPM0-zlXKWbm-ewhveMp48DNkC8iMC2zvnG_YWOMj8m8TQ5zphbB7DNXcrJOSsls8pmUnNPtqWs_WuHD6PUdN5dKuII7zei2WTY85kv7gZ8A6Tg5AQDMH5DEEoVthqwvpoyUcVapHyU-IwM47zfDgOwSJ_4457485d.jpg';
            }}
          />
          <div className="space-y-0.5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              <span>Initiative Profile</span>
              <span aria-hidden="true">·</span>
              <span>Dhaka, Bangladesh</span>
            </div>
            <div className="text-sm font-semibold uppercase tracking-wider text-[#7B9B7B]">
              GreenThread Studio Inc.
            </div>
          </div>
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#14532D] text-balance">
          Our Vision for Thoughtful Textiles & Grounded Engineering
        </h1>
        <p className="text-lg text-[#5C564E] leading-relaxed">
          GreenThread Studio was conceived with a straightforward premise: modern everyday textiles should be physically durable, genuinely biodegradable, and designed within the ecological and industrial realities of their origin.
        </p>
      </div>

      {/* Visual Showcase: Workshop & Loom */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-7 overflow-hidden rounded-lg border border-[#E5DFD5] bg-[#EAE4D9]">
          <TextileImage
            src="/images/textile_research_loom.jpg"
            alt="Textile engineering workshop and handloom setup in Dhaka"
            aspectRatioClass="aspect-[16/10]"
            fallbackTitle="Handloom Workshop & Yarn Spools"
            fallbackCategory="Studio Engineering Setup"
          />
          <div className="p-4 bg-[#FBF9F5] border-t border-[#E5DFD5]">
            <p className="text-xs text-[#5C564E]">
              <span className="font-medium text-[#14532D]">Fig. 02</span> — Pilot handloom trials investigating warp tensioning and plant-dyed sample swatches in Dhaka.
            </p>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-6">
          <div className="p-6 bg-[#F4EFE6] rounded border border-[#E5DFD5] space-y-3">
            <h3 className="font-serif text-2xl font-medium text-[#14532D]">
              Why Bangladesh?
            </h3>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              Bangladesh is the world’s second-largest producer of jute and one of the largest garment manufacturing hubs on Earth. This unique confluence offers an unprecedented opportunity to combine agrarian natural bast fiber heritage with vast pre-consumer industrial fabric salvage.
            </p>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              Yet too often, high-value technical innovation happens in overseas design studios while the physical manufacturing centers bear the environmental burden. We base our research and design right here at the source.
            </p>
          </div>

          <div className="border-l-2 border-[#14532D] pl-4 space-y-1">
            <div className="font-serif italic text-base text-[#14532D]">
              "Good textile engineering begins with the fiber's natural state, not an artificial chemical fix."
            </div>
            <div className="text-xs text-[#8C8275]">
              — GreenThread Studio Engineering Working Note
            </div>
          </div>
        </div>
      </div>

      {/* Core Philosophies: 3 Columns */}
      <div className="space-y-8">
        <div className="max-w-2xl space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
            Methodology
          </span>
          <h2 className="font-serif text-3xl font-medium text-[#14532D]">
            Three Tenets of Responsible Textile Design
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="p-8 bg-[#FBF9F5] rounded border border-[#E5DFD5] space-y-4">
            <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-center">
              <Microscope className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-2xl font-medium text-[#14532D]">
              01. Fiber Mechanics First
            </h3>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              Before drawing a silhouette or pattern, we test fiber tensile properties, elongation at break, and wet-to-dry shrink ratios. We do not disguise fragile yarn under synthetic resin coatings; durability must emerge directly from weave architecture.
            </p>
          </div>

          <div className="p-8 bg-[#FBF9F5] rounded border border-[#E5DFD5] space-y-4">
            <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-center">
              <Scale className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-2xl font-medium text-[#14532D]">
              02. Radical Transparency
            </h3>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              We flatly reject marketing buzzwords. If a prototype is in development, we say so. If we have not yet verified laboratory tear strength, we say so. We never claim "carbon negative" or "zero impact" without rigorous, published primary data.
            </p>
          </div>

          <div className="p-8 bg-[#FBF9F5] rounded border border-[#E5DFD5] space-y-4">
            <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-2xl font-medium text-[#14532D]">
              03. Circular Monomateriality
            </h3>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              A cotton bag sewn with nylon thread and lined with synthetic foam is an engineering dead end for biological recycling. Every component in our planned product range—from handles to seams—is specified for clean end-of-life separation.
            </p>
          </div>

        </div>
      </div>

      {/* Honest Transparency Matrix */}
      <div className="bg-[#F4EFE6] p-8 sm:p-12 rounded-lg border border-[#E5DFD5] space-y-8">
        <div className="max-w-2xl space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
            Integrity Standard
          </span>
          <h2 className="font-serif text-3xl font-medium text-[#14532D]">
            Our Commitment to Descriptive Accuracy
          </h2>
          <p className="text-sm text-[#5C564E] leading-relaxed">
            As an early-stage studio preparing our first product prototypes, we believe honesty is the only credible foundation for sustainable development.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-4">
            <div className="flex items-center gap-2 text-[#14532D] font-semibold text-sm">
              <CheckCircle2 className="w-4 h-4 text-[#14532D]" />
              <span>What We Do & Verify</span>
            </div>
            <ul className="text-xs sm:text-sm text-[#5C564E] space-y-2.5">
              <li className="flex items-start gap-2">
                <span className="text-[#14532D] font-bold">✓</span>
                <span>Document real textile engineering challenges and raw fiber blend behavior.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#14532D] font-bold">✓</span>
                <span>Source genuine pre-consumer textile offcuts directly from regional cutting floors.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#14532D] font-bold">✓</span>
                <span>Work directly with local handloom artisans in Bangladesh at fair, transparent wage rates.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#14532D] font-bold">✓</span>
                <span>Share open research notes with students, researchers, and circular practitioners.</span>
              </li>
            </ul>
          </div>

          <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-4">
            <div className="flex items-center gap-2 text-[#8C8275] font-semibold text-sm">
              <AlertCircle className="w-4 h-4 text-[#8C8275]" />
              <span>What We Do NOT Claim</span>
            </div>
            <ul className="text-xs sm:text-sm text-[#5C564E] space-y-2.5">
              <li className="flex items-start gap-2">
                <span className="text-[#8C8275] font-bold">✕</span>
                <span>We do not claim commercial sales, retail distribution, or mass production capacity.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8C8275] font-bold">✕</span>
                <span>We do not publish unsubstantiated "carbon offset" or "liters of water saved" marketing claims.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8C8275] font-bold">✕</span>
                <span>We do not claim third-party certifications (GOTS, Fair Trade, OEKO-TEX) that we have not yet formally completed.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#8C8275] font-bold">✕</span>
                <span>We do not claim fictional corporate partnerships or global brand associations.</span>
              </li>
            </ul>
          </div>

        </div>
      </div>

      {/* Studio Team & Location */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 border-t border-[#E5DFD5] pt-16">
        <div className="lg:col-span-4 space-y-3">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
            Studio Origins
          </span>
          <h3 className="font-serif text-3xl font-medium text-[#14532D]">
            Based in Dhaka, Bangladesh
          </h3>
          <p className="text-sm text-[#5C564E] leading-relaxed">
            Our exploratory workshop brings together textile engineers, pattern designers, and handloom weavers working collaboratively in Dhaka.
          </p>
        </div>

        <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="p-6 bg-[#FBF9F5] rounded border border-[#E5DFD5] space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#14532D]">
              Research & Prototyping Workshop
            </div>
            <div className="text-sm font-medium text-[#2D312E]">
              GreenThread Studio Lab
            </div>
            <p className="text-xs text-[#5C564E] leading-relaxed">
              Dhaka, Bangladesh <span className="text-[#8C8275]">[Editable address placeholder: Road 11, Banani / Gulshan, Dhaka 1212]</span>
            </p>
            <div className="pt-2 text-xs text-[#8C8275]">
              Focused on yarn count testing, pattern grading, and handloom sample weaving.
            </div>
          </div>

          <div className="p-6 bg-[#FBF9F5] rounded border border-[#E5DFD5] space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#14532D]">
              Initiative Leadership
            </div>
            <div className="text-sm font-medium text-[#2D312E]">
              Textile Engineering Working Group
            </div>
            <p className="text-xs text-[#5C564E] leading-relaxed">
              Led by textile engineers and circular designers educated in Bangladesh <span className="text-[#8C8275]">[Editable founder and contributor credentials placeholder]</span>.
            </p>
            <div className="pt-2 text-xs text-[#8C8275]">
              Committed to open methodology and transparent peer review.
            </div>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-8 bg-[#E8F0E8] rounded border border-[#D5E3D5]">
        <div>
          <h4 className="font-serif text-2xl font-medium text-[#14532D]">
            Ready to review our technical prototypes?
          </h4>
          <p className="text-xs sm:text-sm text-[#5C564E]">
            Examine our planned reusable carryalls and reclaimed accessory specs.
          </p>
        </div>
        <button
          onClick={() => onNavigate('prototypes')}
          className="cursor-pointer px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors whitespace-nowrap"
        >
          View Prototype Catalog
        </button>
      </div>

    </div>
  );
};
