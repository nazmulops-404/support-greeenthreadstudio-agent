import React, { useState, useEffect } from 'react';
import { PageId, SubmissionCategory } from '../types';
import { useAuth } from '../context/AuthContext';
import { submissionService } from '../services/submissionService';
import { Lightbulb, Send, CheckCircle2, AlertCircle, Copy, Check, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';

interface SubmitIdeaPageProps {
  onNavigate: (page: PageId) => void;
}

export const SubmitIdeaPage: React.FC<SubmitIdeaPageProps> = ({ onNavigate }) => {
  const { user, isConfigured, openAuthModal } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<SubmissionCategory>('reclaimed_fabrics');
  const [description, setDescription] = useState('');
  
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successData, setSuccessData] = useState<{ id: string; claimToken: string } | null>(null);
  const [copiedToken, setCopiedToken] = useState(false);

  // Auto-fill from authenticated user
  useEffect(() => {
    if (user) {
      if (user.displayName && !name) setName(user.displayName);
      if (user.email && !email) setEmail(user.email);
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Frontend validation
    if (!name.trim() || name.trim().length < 2) {
      setError('Please provide your name (at least 2 characters).');
      return;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please provide a valid email address.');
      return;
    }
    if (!title.trim() || title.trim().length < 3) {
      setError('Please provide a descriptive idea title (at least 3 characters).');
      return;
    }
    if (!description.trim() || description.trim().length < 20) {
      setError('Please provide a detailed description (at least 20 characters) explaining your textile idea.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await submissionService.submitIdea(
        {
          name: name.trim(),
          email: email.trim(),
          title: title.trim(),
          category,
          description: description.trim(),
        },
        user
      );
      setSuccessData(res);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to submit idea. Please check your network and configuration.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyToken = () => {
    if (!successData?.claimToken) return;
    navigator.clipboard?.writeText(successData.claimToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2500);
  };

  const handleReset = () => {
    setTitle('');
    setDescription('');
    setCategory('reclaimed_fabrics');
    setError(null);
    setSuccessData(null);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      
      {/* Header */}
      <div className="space-y-4 text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
          <span>Open Innovation</span>
          <span aria-hidden="true">·</span>
          <span>Community Submissions</span>
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl font-medium tracking-tight text-[#14532D]">
          Submit a Textile Idea or Concept
        </h1>
        <p className="text-base text-[#5C564E] leading-relaxed">
          Have an idea for natural bast fiber applications, garment factory scrap salvage, or low-impact finishing? We welcome ideas from artisans, students, researchers, and creators worldwide.
        </p>
      </div>

      {/* Missing Firebase configuration callout */}
      {!isConfigured && (
        <div className="p-4 bg-[#F4EFE6] border border-[#D5CEBF] rounded text-xs text-[#5C564E] flex items-start gap-3">
          <AlertCircle className="w-4 h-4 text-[#8C6D23] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-[#14532D]">Firebase Firestore Notice:</span>
            <p>
              Live database storage requires your <code className="font-mono bg-white px-1 py-0.5 rounded border border-[#E5DFD5]">VITE_FIREBASE_*</code> environment variables in <code className="font-mono">.env</code> or Vercel.
            </p>
          </div>
        </div>
      )}

      {/* Submission Success Screen */}
      {successData ? (
        <div className="bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] p-6 sm:p-10 shadow-xs space-y-8 animate-in fade-in duration-300">
          <div className="text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#E8F0E8] text-[#14532D] flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="font-serif text-3xl font-medium text-[#14532D]">
              Idea Received by GreenThread Studio
            </h2>
            <p className="text-sm text-[#5C564E] max-w-lg mx-auto">
              Thank you, <strong>{name}</strong>! Your concept <em>"{title}"</em> has been logged in our research review queue under status <strong>Received</strong>.
            </p>
          </div>

          {/* Secure Claim / Tracking Card */}
          <div className="p-6 bg-[#F4EFE6] rounded border border-[#E5DFD5] space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#14532D] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#7B9B7B]" />
                  Secure Submission Reference Token
                </span>
                <p className="text-xs text-[#5C564E]">
                  Keep this token to link or verify your submission at any time:
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopyToken}
                className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-white hover:bg-[#EAE4D9] rounded border border-[#E5DFD5] transition-colors shrink-0"
              >
                {copiedToken ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#14532D]" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Token</span>
                  </>
                )}
              </button>
            </div>

            <div className="p-3 bg-white rounded border border-[#E5DFD5] font-mono text-sm sm:text-base font-semibold text-[#14532D] tracking-wider select-all break-all text-center">
              {successData.claimToken}
            </div>

            <div className="text-xs text-[#5C564E] space-y-1">
              <p>
                <strong>Security Protection:</strong> To protect submitter privacy, submissions cannot be viewed by simply searching an email address.
              </p>
              {!user ? (
                <p>
                  You submitted as a guest. When you sign up or log in using <strong>{email}</strong>, you can link this idea to your account dashboard using this token.
                </p>
              ) : (
                <p className="text-[#14532D] font-medium">
                  ✓ Automatically linked to your signed-in account ({user.email}).
                </p>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            {!user ? (
              <button
                type="button"
                onClick={() => openAuthModal('signup')}
                className="cursor-pointer w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors shadow-xs"
              >
                Create Account to Track Status
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate('my-submissions')}
                className="cursor-pointer w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors shadow-xs"
              >
                View in My Submissions
              </button>
            )}

            <button
              type="button"
              onClick={handleReset}
              className="cursor-pointer w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
            >
              Submit Another Concept
            </button>
          </div>
        </div>
      ) : (
        /* Idea Submission Form */
        <div className="bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] p-6 sm:p-10 shadow-xs space-y-6">
          
          <div className="border-b border-[#E5DFD5] pb-4 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-[#7B9B7B]">
              <Lightbulb className="w-4 h-4 text-[#14532D]" />
              <span className="font-semibold text-[#14532D]">No Account Required</span>
              <span aria-hidden="true">·</span>
              <span>Open to all visitors</span>
            </div>
            {user && (
              <span className="text-xs text-[#14532D] bg-[#E8F0E8] px-2.5 py-1 rounded">
                Signed in as {user.email}
              </span>
            )}
          </div>

          {error && (
            <div className="p-3.5 bg-red-50 border border-red-200 rounded flex items-start gap-2.5 text-xs text-red-800 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Name & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Your Name <span className="text-[#8C6D23]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Maya Rahman"
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Email Address <span className="text-[#8C6D23]">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. maya@domain.com"
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                />
                <span className="text-[11px] text-[#8C8275]">
                  Used to securely verify ownership if you claim this idea later.
                </span>
              </div>
            </div>

            {/* Title & Category */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6">
              <div className="sm:col-span-7 space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Idea Title <span className="text-[#8C6D23]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Reclaimed Selvedge Twill for Heavy-Duty Tool Rolls"
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                />
              </div>

              <div className="sm:col-span-5 space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Category <span className="text-[#8C6D23]">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as SubmissionCategory)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                >
                  <option value="reclaimed_fabrics">Reclaimed Mill Remnants / Jhoot</option>
                  <option value="natural_fibers">Indigenous Bast Fibers / Jute Blends</option>
                  <option value="circular_design">Design for Disassembly / Mono-Materials</option>
                  <option value="dyeing_finishing">Natural & Enzymatic Finishing</option>
                  <option value="other">Other Textile Engineering Ideas</option>
                </select>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Detailed Description & Rationale <span className="text-[#8C6D23]">*</span>
                </label>
                <span className="text-[11px] text-[#8C8275]">
                  {description.length} / 3000 chars (min 20)
                </span>
              </div>
              <textarea
                required
                rows={6}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explain the material composition, intended everyday utility, why this reduces environmental impact, and any textile engineering testing parameters you recommend..."
                className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors resize-y"
              />
            </div>

            {/* Submit Action */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-[#E5DFD5]">
              <span className="text-xs text-[#8C8275]">
                Submissions are governed by GreenThread Studio Inc.'s open engineering principles.
              </span>
              <button
                type="submit"
                disabled={submitting}
                className="cursor-pointer w-full sm:w-auto px-7 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] disabled:opacity-60 rounded transition-all shadow-xs flex items-center justify-center gap-2 whitespace-nowrap"
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Recording Submission...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Idea</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>
      )}

    </div>
  );
};
