import React, { useState } from 'react';
import { PageId, PrototypeItem } from '../types';
import { PROTOTYPES } from '../data/prototypes';
import { TextileImage } from '../components/TextileImage';
import { Layers, ArrowRight, X, ExternalLink, SlidersHorizontal, Check, AlertCircle } from 'lucide-react';

interface PrototypesPageProps {
  onNavigate: (page: PageId) => void;
  selectedPrototypeId?: string | null;
  onClearSelectedPrototype?: () => void;
}

export const PrototypesPage: React.FC<PrototypesPageProps> = ({
  onNavigate,
  selectedPrototypeId,
  onClearSelectedPrototype,
}) => {
  const [filter, setFilter] = useState<'all' | 'bags' | 'accessories'>('all');
  const [activeModalItem, setActiveModalItem] = useState<PrototypeItem | null>(() => {
    if (selectedPrototypeId) {
      return PROTOTYPES.find((p) => p.id === selectedPrototypeId) || null;
    }
    return null;
  });

  const filteredItems = PROTOTYPES.filter((item) => {
    if (filter === 'all') return true;
    return item.category === filter;
  });

  const handleOpenModal = (item: PrototypeItem) => {
    setActiveModalItem(item);
  };

  const handleCloseModal = () => {
    setActiveModalItem(null);
    onClearSelectedPrototype?.();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      
      {/* Header & Editorial Context */}
      <div className="max-w-3xl space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
          <span>Product Development Pipeline</span>
          <span aria-hidden="true">·</span>
          <span>Prototypes in Evaluation</span>
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl font-medium tracking-tight text-[#14532D]">
          Products & Prototypes
        </h1>
        <p className="text-base sm:text-lg text-[#5C564E] leading-relaxed">
          Every concept below represents an active material or pattern trial at our studio in Dhaka. In adherence to our strict transparency standard, all items are marked <strong>In Development</strong> and are not currently available for commercial sale.
        </p>
      </div>

      {/* Prominent Stage Disclaimer Box */}
      <div className="bg-[#E8F0E8] border border-[#D5E3D5] p-5 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-[#2D312E] leading-relaxed">
            <span className="font-semibold text-[#14532D]">Development Notice:</span> We do not accept retail orders or payments. If your organization or research department is interested in testing textile swatches or collaborating on tensile wear trials, please submit a sample inquiry.
          </div>
        </div>
        <button
          onClick={() => onNavigate('contact')}
          className="cursor-pointer shrink-0 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors whitespace-nowrap"
        >
          Research Inquiry
        </button>
      </div>

      {/* Filter Bar (Segmented Controls) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5DFD5] pb-4">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#7B9B7B]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[#14532D]">
            Filter Concepts:
          </span>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[#F4EFE6] rounded border border-[#E5DFD5]">
          <button
            onClick={() => setFilter('all')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'all'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            All Concepts ({PROTOTYPES.length})
          </button>
          <button
            onClick={() => setFilter('bags')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'bags'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            Planned Reusable Bags (2)
          </button>
          <button
            onClick={() => setFilter('accessories')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'accessories'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            Reclaimed Accessories (2)
          </button>
        </div>
      </div>

      {/* Prototype Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
        {filteredItems.map((proto) => (
          <div
            key={proto.id}
            className="bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] overflow-hidden flex flex-col justify-between hover:border-[#14532D]/40 transition-all shadow-xs group"
          >
            <div>
              {/* Media Card */}
              <div className="relative aspect-[16/10] bg-[#EAE4D9] overflow-hidden">
                <TextileImage
                  src={proto.primaryImage}
                  alt={proto.name}
                  aspectRatioClass="aspect-[16/10]"
                  fallbackTitle={proto.name}
                  fallbackCategory={proto.categoryLabel}
                />
                
                {/* Code & In Development Tag */}
                <div className="absolute top-3 left-3 flex items-center gap-2 z-10">
                  <span className="bg-[#14532D] text-[#FBF9F5] text-[11px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-xs">
                    {proto.code}
                  </span>
                  <span className="bg-[#FBF9F5]/90 backdrop-blur-xs text-[#14532D] text-[11px] font-medium px-2 py-0.5 rounded-xs border border-[#E5DFD5]">
                    In Development
                  </span>
                </div>

                <div className="absolute bottom-3 right-3 bg-[#1C1917]/80 text-[#FBF9F5] text-[10px] px-2 py-1 rounded-xs backdrop-blur-xs">
                  {proto.stage}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-8 space-y-4">
                <div className="text-xs text-[#7B9B7B] flex items-center gap-2">
                  <span className="font-semibold text-[#14532D]">{proto.categoryLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{proto.developmentStatus}</span>
                </div>

                <h3 className="font-serif text-2xl font-medium text-[#14532D]">
                  {proto.name}
                </h3>

                <p className="text-sm text-[#5C564E] leading-relaxed">
                  {proto.shortDescription}
                </p>

                {/* Technical Specifications Summary */}
                <div className="pt-3 border-t border-[#E5DFD5] text-xs text-[#5C564E] space-y-2">
                  <div className="flex items-start justify-between gap-4">
                    <span className="font-medium text-[#2D312E]">Fiber Composition:</span>
                    <span className="text-right">{proto.fiberComposition}</span>
                  </div>
                  <div className="flex items-start justify-between gap-4">
                    <span className="font-medium text-[#2D312E]">Weave Architecture:</span>
                    <span className="text-right">{proto.weaveStructure}</span>
                  </div>
                  <div className="flex items-start justify-between gap-4">
                    <span className="font-medium text-[#2D312E]">Estimated Dimensions:</span>
                    <span className="text-right">{proto.dimensionsEstimated}</span>
                  </div>
                </div>

                {/* Honest Limitation Preview */}
                <div className="p-3 bg-[#F4EFE6] rounded text-[11px] text-[#5C564E] leading-normal border border-[#E5DFD5]/80">
                  <strong className="text-[#14532D]">Honest Note:</strong> {proto.honestLimitation}
                </div>
              </div>
            </div>

            {/* Card Actions */}
            <div className="p-6 sm:p-8 pt-0 flex items-center gap-3">
              <button
                onClick={() => handleOpenModal(proto)}
                className="cursor-pointer flex-1 text-center py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
              >
                Full Prototype Specs
              </button>
              <button
                onClick={() => onNavigate('contact')}
                className="cursor-pointer px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors"
              >
                Inquire
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal / Detailed Specification Inspector */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-xl relative animate-in fade-in duration-200">
            
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#FBF9F5]/95 backdrop-blur-xs px-6 sm:px-8 py-5 border-b border-[#E5DFD5] flex items-center justify-between z-10">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2 text-xs text-[#7B9B7B]">
                  <span className="font-mono bg-[#14532D] text-[#FBF9F5] px-1.5 py-0.5 rounded-xs text-[10px]">
                    {activeModalItem.code}
                  </span>
                  <span className="font-semibold text-[#14532D]">{activeModalItem.developmentStatus}</span>
                </div>
                <h2 className="font-serif text-2xl font-medium text-[#14532D]">
                  {activeModalItem.name}
                </h2>
              </div>
              <button
                onClick={handleCloseModal}
                className="p-1.5 text-[#5C564E] hover:text-[#14532D] rounded hover:bg-[#EAE4D9] transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 sm:p-8 space-y-6">
              
              {/* Image Banner */}
              <div className="relative aspect-[16/9] rounded overflow-hidden bg-[#EAE4D9] border border-[#E5DFD5]">
                <TextileImage
                  src={activeModalItem.primaryImage}
                  alt={activeModalItem.name}
                  aspectRatioClass="aspect-[16/9]"
                  fallbackTitle={activeModalItem.name}
                  fallbackCategory={activeModalItem.categoryLabel}
                />
              </div>

              {/* Detailed Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
                  Concept & Structural Rationale
                </h4>
                <p className="text-sm text-[#4A453E] leading-relaxed">
                  {activeModalItem.fullDescription}
                </p>
              </div>

              {/* Technical Specifications Table */}
              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
                  Material & Assembly Specifications
                </h4>
                <div className="border border-[#E5DFD5] rounded overflow-hidden bg-[#F4EFE6]/60">
                  <div className="divide-y divide-[#E5DFD5] text-xs">
                    <div className="grid grid-cols-3 p-3">
                      <span className="font-medium text-[#14532D]">Fiber Composition</span>
                      <span className="col-span-2 text-[#2D312E]">{activeModalItem.fiberComposition}</span>
                    </div>
                    <div className="grid grid-cols-3 p-3">
                      <span className="font-medium text-[#14532D]">Weave Architecture</span>
                      <span className="col-span-2 text-[#2D312E]">{activeModalItem.weaveStructure}</span>
                    </div>
                    <div className="grid grid-cols-3 p-3">
                      <span className="font-medium text-[#14532D]">Dimensions (Est.)</span>
                      <span className="col-span-2 text-[#2D312E]">{activeModalItem.dimensionsEstimated}</span>
                    </div>
                    {activeModalItem.secondaryDetails.map((detail, idx) => (
                      <div key={idx} className="grid grid-cols-3 p-3">
                        <span className="font-medium text-[#14532D]">{detail.label}</span>
                        <span className="col-span-2 text-[#2D312E]">{detail.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Active Research Objectives */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
                  Current Laboratory & Studio Testing Targets
                </h4>
                <ul className="space-y-2 text-xs text-[#5C564E]">
                  {activeModalItem.researchObjectives.map((obj, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-[#14532D] font-bold">·</span>
                      <span>{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Honest Limitation Declaration */}
              <div className="p-4 bg-[#F4EFE6] border border-[#E5DFD5] rounded text-xs space-y-1">
                <div className="font-semibold text-[#14532D]">
                  Development & Sourcing Limitation
                </div>
                <p className="text-[#5C564E] leading-relaxed">
                  {activeModalItem.honestLimitation}
                </p>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-[#F4EFE6] px-6 sm:px-8 py-4 border-t border-[#E5DFD5] flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-[#8C8275]">
                Prototype code: {activeModalItem.code} · Dhaka workshop
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCloseModal}
                  className="cursor-pointer px-4 py-2 text-xs font-medium text-[#5C564E] hover:text-[#14532D]"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    handleCloseModal();
                    onNavigate('contact');
                  }}
                  className="cursor-pointer px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors"
                >
                  Contact About This Prototype
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
