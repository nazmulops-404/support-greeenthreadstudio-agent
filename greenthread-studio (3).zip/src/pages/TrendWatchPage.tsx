import React, { useState } from 'react';
import { PageId } from '../types';
import { TREND_WATCH_ITEMS } from '../data/trendWatch';
import { ExternalLink, CheckCircle2, Clock, Filter, AlertCircle, Info, BookOpen } from 'lucide-react';

interface TrendWatchPageProps {
  onNavigate: (page: PageId) => void;
}

export const TrendWatchPage: React.FC<TrendWatchPageProps> = ({ onNavigate }) => {
  const [filter, setFilter] = useState<'all' | 'verified' | 'placeholder'>('all');

  const filteredItems = TREND_WATCH_ITEMS.filter((item) => {
    if (filter === 'verified') return item.isVerifiedSource;
    if (filter === 'placeholder') return !item.isVerifiedSource;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      
      {/* Header */}
      <div className="max-w-3xl space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
          <span>Industry Intelligence</span>
          <span aria-hidden="true">·</span>
          <span>Verified Sources & Research Dispatches</span>
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl font-medium tracking-tight text-[#14532D]">
          Textile Trend Watch
        </h1>
        <p className="text-base sm:text-lg text-[#5C564E] leading-relaxed">
          A curated monitor of circular textile research, regulatory directives, and global fiber market reports. In strict alignment with our honesty charter, we link exclusively to verified external sources, with all ongoing or unverified studio notes clearly marked as placeholders.
        </p>
      </div>

      {/* Verification Standard Banner */}
      <div className="p-5 bg-[#F4EFE6] rounded-lg border border-[#E5DFD5] flex items-start gap-3.5">
        <Info className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
        <div className="text-xs sm:text-sm text-[#5C564E] leading-relaxed space-y-1">
          <p>
            <strong className="text-[#14532D]">Editorial Citation Policy:</strong> We do not fabricate news headlines, academic citations, or URLs. Items below marked as <span className="font-semibold text-[#14532D]">Verified Source</span> connect directly to original publications by recognized institutions. Items marked as <span className="font-semibold text-[#8C8275]">[Placeholder]</span> represent planned studio research awaiting final peer review or field compilation.
          </p>
        </div>
      </div>

      {/* Filter Segmented Control */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5DFD5] pb-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-[#14532D]">
          Viewing: {filteredItems.length} Summaries
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[#F4EFE6] rounded border border-[#E5DFD5]">
          <button
            onClick={() => setFilter('all')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'all'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            All Items ({TREND_WATCH_ITEMS.length})
          </button>
          <button
            onClick={() => setFilter('verified')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'verified'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            Verified External Sources (4)
          </button>
          <button
            onClick={() => setFilter('placeholder')}
            className={`cursor-pointer px-3.5 py-1.5 text-xs font-medium rounded transition-colors ${
              filter === 'placeholder'
                ? 'bg-white text-[#14532D] shadow-xs font-semibold'
                : 'text-[#5C564E] hover:text-[#14532D]'
            }`}
          >
            Studio Research Placeholders (2)
          </button>
        </div>
      </div>

      {/* List of Summaries */}
      <div className="space-y-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className={`p-6 sm:p-8 rounded-lg border transition-all ${
              item.isVerifiedSource
                ? 'bg-[#FBF9F5] border-[#E5DFD5] hover:border-[#14532D]/50 shadow-xs'
                : 'bg-[#F4EFE6]/50 border-dashed border-[#D5CEBF]'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
              
              <div className="space-y-3 max-w-4xl">
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C564E]">
                  <span className="font-semibold text-[#14532D]">{item.organization}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.publicationDate}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#7B9B7B]">{item.focusArea}</span>
                  <span aria-hidden="true">·</span>
                  {item.isVerifiedSource ? (
                    <span className="text-[#14532D] font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Verified Document
                    </span>
                  ) : (
                    <span className="text-[#8C8275] font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" /> In Preparation
                    </span>
                  )}
                </div>

                <h3 className="font-serif text-2xl font-medium text-[#14532D]">
                  {item.title}
                </h3>

                <p className="text-sm text-[#4A453E] leading-relaxed">
                  {item.summary}
                </p>

                {/* Editorial Reflection */}
                <div className="p-3 bg-[#F4EFE6] rounded text-xs text-[#5C564E] border border-[#E5DFD5]/80 space-y-1">
                  <span className="font-medium text-[#14532D]">Relevance to GreenThread Studio:</span>
                  <p className="italic">{item.editorialNote}</p>
                </div>
              </div>

              {/* Action Button */}
              <div className="shrink-0 pt-2 md:pt-0">
                {item.isVerifiedSource ? (
                  <a
                    href={item.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors whitespace-nowrap"
                  >
                    <span>Original Source</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                ) : (
                  <div className="px-3 py-1.5 text-[11px] font-mono text-[#8C8275] bg-[#EAE4D9] rounded border border-[#D5CEBF] whitespace-nowrap">
                    [Placeholder Entry]
                  </div>
                )}
              </div>

            </div>
          </div>
        ))}
      </div>

      {/* Suggest a Source Box */}
      <div className="p-8 bg-[#F4EFE6] rounded border border-[#E5DFD5] flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h4 className="font-serif text-xl font-medium text-[#14532D]">
            Have a verified textile study or peer-reviewed paper to share?
          </h4>
          <p className="text-xs sm:text-sm text-[#5C564E]">
            We track academic research on bast fibers, enzymatic retting, and textile scrap segregation.
          </p>
        </div>
        <button
          onClick={() => onNavigate('contact')}
          className="cursor-pointer px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors whitespace-nowrap"
        >
          Submit Research Link
        </button>
      </div>

    </div>
  );
};
