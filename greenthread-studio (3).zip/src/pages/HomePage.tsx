import React from 'react';
import { PageId } from '../types';
import { PROTOTYPES } from '../data/prototypes';
import { JOURNAL_ARTICLES } from '../data/journal';
import { TextileImage } from '../components/TextileImage';
import { ArrowRight, Compass, ShieldCheck, RefreshCw, Feather, Layers } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onSelectArticle?: (articleId: string) => void;
  onSelectPrototype?: (prototypeId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onSelectArticle,
  onSelectPrototype,
}) => {
  const featuredPrototypes = PROTOTYPES.slice(0, 3);
  const featuredArticle = JOURNAL_ARTICLES[0];

  return (
    <div className="space-y-20 lg:space-y-28">
      
      {/* Hero Section */}
      <section className="relative pt-6 sm:pt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left Narrative Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center gap-3.5">
                <img
                  src="/images/logo.jpg"
                  alt="GreenThread Studio Inc. Official Logo"
                  className="h-11 w-11 sm:h-12 sm:w-12 rounded-full object-contain bg-white border border-[#14532D]/20 p-0.5 shadow-xs shrink-0"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/assets/aistudio/iZqx5jgZ2fFL5zTQa_i632ncu-ulOcxgsElkkvHaPM0-zlXKWbm-ewhveMp48DNkC8iMC2zvnG_YWOMj8m8TQ5zphbB7DNXcrJOSsls8pmUnNPtqWs_WuHD6PUdN5dKuII7zei2WTY85kv7gZ8A6Tg5AQDMH5DEEoVthqwvpoyUcVapHyU-IwM47zfDgOwSJ_4457485d.jpg';
                  }}
                />
                <div className="space-y-0.5">
                  <div className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
                    GreenThread Studio Inc.
                  </div>
                  <div className="text-[11px] text-[#7B9B7B] tracking-wider uppercase font-medium">
                    Dhaka, Bangladesh &bull; Sustainable Textile Initiative
                  </div>
                </div>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#14532D] leading-[1.1] text-balance">
                Thoughtful Textiles for Everyday Life.
              </h1>

              <p className="text-base sm:text-lg text-[#4A453E] leading-relaxed max-w-2xl">
                GreenThread Studio is an early-stage exploratory textile studio in Bangladesh. We bridge indigenous natural bast fibers—such as raw golden jute—with pre-consumer garment cutting remnants to develop honest, long-lasting everyday carryalls and functional accessories.
              </p>

              {/* Stage Transparency Pill-Free Note */}
              <div className="p-4 bg-[#F4EFE6] border border-[#E5DFD5] rounded text-xs text-[#5C564E] leading-relaxed">
                <span className="font-semibold text-[#14532D]">Current Initiative Status:</span> We are currently manufacturing and testing our first batch of physical prototypes in Dhaka. We do not sell finished goods or claim speculative carbon offsets—every product concept shown is under active development.
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate('prototypes')}
                  className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-all shadow-xs"
                >
                  <span>Explore Prototypes</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate('about')}
                  className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-all"
                >
                  <span>Our Vision & Research</span>
                </button>
              </div>
            </div>

            {/* Right Media Hero Column */}
            <div className="lg:col-span-5">
              <div className="relative group overflow-hidden rounded-lg bg-[#EAE4D9] border border-[#E5DFD5] shadow-xs">
                <TextileImage
                  src="/images/hero_textile.jpg"
                  alt="Tactile raw golden jute and organic cotton weave texture"
                  aspectRatioClass="aspect-[4/3] lg:aspect-[1/1]"
                  fallbackTitle="Handloom Jute-Cotton Weave Swatch"
                  fallbackCategory="Raw Material Inspection"
                />
                <div className="p-4 bg-[#FBF9F5]/95 border-t border-[#E5DFD5]">
                  <p className="text-xs text-[#5C564E]">
                    <span className="font-medium text-[#14532D]">Fig. 01</span> — Close-up structural inspection of untreated handloom jute-cotton hybrid fabric swatch in Dhaka.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Mission & Core Focus Areas */}
      <section className="bg-[#F4EFE6]/60 border-y border-[#E5DFD5] py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="max-w-2xl space-y-3">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              Our Foundation
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#14532D]">
              Four Pillars of Material Integrity
            </h2>
            <p className="text-sm sm:text-base text-[#5C564E] leading-relaxed">
              We focus on practical textile engineering rather than surface sustainability labels. Our studio workflow prioritizes physical durability, repairability, and monomaterial end-of-life cycles.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-between p-2.5">
                  <Feather className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-xl font-medium text-[#14532D]">
                  Natural Fiber Blending
                </h3>
                <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed">
                  Leveraging indigenous Bangladesh golden jute for high tensile vertical load resistance, balanced with unbleached organic cotton for lateral flexural durability.
                </p>
              </div>
              <div className="text-xs text-[#14532D] font-medium pt-3 border-t border-[#E5DFD5]">
                Zero synthetic fiber blends
              </div>
            </div>

            <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-between p-2.5">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-xl font-medium text-[#14532D]">
                  Pre-Consumer Offcut Salvage
                </h3>
                <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed">
                  Direct sourcing of clean, unlaundered factory cutting-room remnants (jhoot) from export mills in Gazipur and Narayanganj before downcycling or incineration.
                </p>
              </div>
              <div className="text-xs text-[#14532D] font-medium pt-3 border-t border-[#E5DFD5]">
                100% Cotton offcut verification
              </div>
            </div>

            <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-between p-2.5">
                  <Layers className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-xl font-medium text-[#14532D]">
                  Artisanal Handloom Weaving
                </h3>
                <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed">
                  Partnering with regional weaver collectives in Tangail and Narsingdi to preserve low-energy pedal loom production methods that respect fiber structure.
                </p>
              </div>
              <div className="text-xs text-[#14532D] font-medium pt-3 border-t border-[#E5DFD5]">
                Low-energy mechanical craft
              </div>
            </div>

            <div className="bg-[#FBF9F5] p-6 rounded border border-[#E5DFD5] space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded bg-[#E8F0E8] text-[#14532D] flex items-center justify-between p-2.5">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-xl font-medium text-[#14532D]">
                  Design for Disassembly
                </h3>
                <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed">
                  Eliminating toxic adhesive laminates and synthetic stiffening foams. We construct bags with single-fiber cotton sewing threads and mechanical brass hardware.
                </p>
              </div>
              <div className="text-xs text-[#14532D] font-medium pt-3 border-t border-[#E5DFD5]">
                Repairable & recyclable assemblies
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Featured Prototypes Spotlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E5DFD5] pb-5">
          <div className="space-y-2">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              Product Development Pipeline
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#14532D]">
              Prototypes in Active Evaluation
            </h2>
          </div>
          <button
            onClick={() => onNavigate('prototypes')}
            className="cursor-pointer inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E] transition-colors"
          >
            <span>View All 4 Concepts</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredPrototypes.map((proto) => (
            <div
              key={proto.id}
              className="bg-[#FBF9F5] rounded border border-[#E5DFD5] overflow-hidden flex flex-col justify-between group hover:border-[#14532D]/40 transition-colors"
            >
              <div>
                <div className="relative aspect-[4/3] overflow-hidden bg-[#EAE4D9]">
                  <TextileImage
                    src={proto.primaryImage}
                    alt={proto.name}
                    aspectRatioClass="aspect-[4/3]"
                    fallbackTitle={proto.name}
                    fallbackCategory={proto.categoryLabel}
                  />
                  <div className="absolute top-3 left-3 bg-[#14532D] text-[#FBF9F5] text-[11px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-xs z-10">
                    {proto.code}
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <div className="flex items-center gap-2 text-xs text-[#7B9B7B]">
                    <span className="font-medium text-[#14532D]">{proto.developmentStatus}</span>
                    <span aria-hidden="true">·</span>
                    <span>{proto.categoryLabel}</span>
                  </div>

                  <h3 className="font-serif text-xl font-medium text-[#14532D] leading-snug">
                    {proto.name}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed line-clamp-2">
                    {proto.shortDescription}
                  </p>

                  <div className="pt-2 text-xs text-[#5C564E] space-y-1 border-t border-[#E5DFD5]">
                    <div><strong>Fiber:</strong> {proto.fiberComposition}</div>
                    <div><strong>Structure:</strong> {proto.weaveStructure}</div>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={() => {
                    onSelectPrototype?.(proto.id);
                    onNavigate('prototypes');
                  }}
                  className="cursor-pointer w-full text-center py-2.5 px-3 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
                >
                  View Technical Spec
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Journal Feature Section */}
      <section className="bg-[#F4EFE6] border-y border-[#E5DFD5] py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
                From The Studio Journal
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#14532D]">
                Grounded Research Notes on Textile Mechanics
              </h2>
              <p className="text-sm text-[#5C564E] leading-relaxed">
                We believe in publishing the candid successes and failures of our material trials. Explore our technical field notes on bast fiber elasticity, cutting-room offcut segregation, and why we refuse unverified carbon claims.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => onNavigate('journal')}
                  className="cursor-pointer inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E] underline underline-offset-4"
                >
                  <span>Explore All Journal Articles</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-7">
              <div className="bg-[#FBF9F5] p-8 sm:p-10 rounded border border-[#E5DFD5] shadow-xs space-y-4">
                <div className="flex items-center gap-2 text-xs text-[#7B9B7B]">
                  <span className="font-medium text-[#14532D]">{featuredArticle.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredArticle.date}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredArticle.readTime}</span>
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl font-medium text-[#14532D]">
                  {featuredArticle.title}
                </h3>

                <p className="text-sm text-[#5C564E] leading-relaxed">
                  {featuredArticle.abstract}
                </p>

                <div className="pt-4 border-t border-[#E5DFD5] flex items-center justify-between">
                  <span className="text-xs text-[#8C8275]">Published by GreenThread Engineering Collective</span>
                  <button
                    onClick={() => {
                      onSelectArticle?.(featuredArticle.id);
                      onNavigate('journal');
                    }}
                    className="cursor-pointer text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E]"
                  >
                    Read Full Paper &rarr;
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Call to Dialogue / Academic Collaboration Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#14532D] text-[#FBF9F5] p-8 sm:p-12 lg:p-14 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="max-w-2xl space-y-3">
            <span className="text-xs uppercase tracking-widest text-[#87A987] font-semibold">
              Research & Artisan Collaboration
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-medium text-white">
              Are you a textile engineer, artisan, or circular designer?
            </h2>
            <p className="text-sm sm:text-base text-[#D5E3D5] leading-relaxed">
              We welcome academic exchange, yarn sample testing, and feedback on our open prototypes from institutions and makers worldwide.
            </p>
          </div>

          <div className="shrink-0 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onNavigate('submit-idea')}
              className="cursor-pointer px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#FBF9F5] hover:bg-[#EAE4D9] rounded transition-colors whitespace-nowrap"
            >
              Submit an Idea
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="cursor-pointer px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white border border-[#87A987] hover:bg-[#0D381E] rounded transition-colors whitespace-nowrap"
            >
              Contact Studio
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
