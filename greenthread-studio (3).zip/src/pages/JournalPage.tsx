import React, { useState } from 'react';
import { PageId, JournalArticle } from '../types';
import { JOURNAL_ARTICLES } from '../data/journal';
import { TextileImage } from '../components/TextileImage';
import { ArrowLeft, BookOpen, Clock, Calendar, User, Share2, Check, ArrowRight } from 'lucide-react';

interface JournalPageProps {
  onNavigate: (page: PageId) => void;
  selectedArticleId?: string | null;
  onClearSelectedArticle?: () => void;
}

export const JournalPage: React.FC<JournalPageProps> = ({
  onNavigate,
  selectedArticleId,
  onClearSelectedArticle,
}) => {
  const [activeArticle, setActiveArticle] = useState<JournalArticle | null>(() => {
    if (selectedArticleId) {
      return JOURNAL_ARTICLES.find((a) => a.id === selectedArticleId) || null;
    }
    return null;
  });
  const [copied, setCopied] = useState(false);

  const handleSelectArticle = (article: JournalArticle) => {
    setActiveArticle(article);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToList = () => {
    setActiveArticle(null);
    onClearSelectedArticle?.();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCopyCitation = () => {
    if (!activeArticle) return;
    const citation = `"${activeArticle.title}." ${activeArticle.author}, GreenThread Studio Research Journal, ${activeArticle.date}. Dhaka, Bangladesh.`;
    navigator.clipboard?.writeText(citation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* If viewing a single full article (Reusable Article Layout) */}
      {activeArticle ? (
        <article className="max-w-3xl mx-auto space-y-10 animate-in fade-in duration-200">
          
          {/* Breadcrumb / Back button */}
          <div className="flex items-center justify-between border-b border-[#E5DFD5] pb-4">
            <button
              onClick={handleBackToList}
              className="cursor-pointer inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to All Articles</span>
            </button>

            <button
              onClick={handleCopyCitation}
              className="cursor-pointer inline-flex items-center gap-1.5 text-xs text-[#5C564E] hover:text-[#14532D] transition-colors"
              title="Copy academic citation"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#14532D]" />
                  <span className="text-[#14532D] font-medium">Citation Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Copy Citation</span>
                </>
              )}
            </button>
          </div>

          {/* Article Header */}
          <header className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C564E]">
              <span className="font-semibold text-[#14532D] uppercase tracking-wider">{activeArticle.category}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {activeArticle.date}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {activeArticle.readTime}</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-medium tracking-tight text-[#14532D] leading-[1.15] text-balance">
              {activeArticle.title}
            </h1>

            <p className="font-serif italic text-lg sm:text-xl text-[#4A453E] leading-relaxed">
              {activeArticle.subtitle}
            </p>

            <div className="pt-2 text-xs text-[#8C8275] border-t border-[#E5DFD5]">
              By {activeArticle.author} · Dhaka Workshop
            </div>
          </header>

          {/* Abstract Box */}
          <div className="p-6 bg-[#F4EFE6] rounded border border-[#E5DFD5] space-y-2">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              Abstract & Executive Summary
            </span>
            <p className="text-sm text-[#4A453E] leading-relaxed italic">
              {activeArticle.abstract}
            </p>
          </div>

          {/* Featured Article Figure */}
          {activeArticle.image && (
            <div className="rounded-lg overflow-hidden border border-[#E5DFD5] bg-[#EAE4D9]">
              <TextileImage
                src={activeArticle.image}
                alt={activeArticle.title}
                aspectRatioClass="aspect-[16/9]"
                fallbackTitle={activeArticle.title}
                fallbackCategory={activeArticle.category}
              />
              <div className="p-3 bg-[#FBF9F5] border-t border-[#E5DFD5] text-xs text-[#5C564E] italic">
                Fig. — Documented textile sample under evaluation at GreenThread Studio in Dhaka.
              </div>
            </div>
          )}

          {/* Article Body with Editorial Typography */}
          <div className="prose prose-stone max-w-none text-base text-[#2D312E] leading-relaxed space-y-6">
            {activeArticle.contentParagraphs.map((para, index) => {
              if (index === 0 && para.type === 'paragraph') {
                return (
                  <p
                    key={index}
                    className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:text-[#14532D] leading-relaxed text-[#2D312E]"
                  >
                    {para.text}
                  </p>
                );
              }

              if (para.type === 'heading') {
                return (
                  <h3
                    key={index}
                    className="font-serif text-2xl font-medium text-[#14532D] pt-6 border-t border-[#E5DFD5] mt-8"
                  >
                    {para.text}
                  </h3>
                );
              }

              if (para.type === 'pullquote') {
                return (
                  <div
                    key={index}
                    className="my-8 py-6 border-y border-[#E5DFD5] text-center px-4"
                  >
                    <blockquote className="font-serif italic text-xl sm:text-2xl text-[#14532D] leading-snug">
                      "{para.text}"
                    </blockquote>
                  </div>
                );
              }

              if (para.type === 'footnote') {
                return (
                  <div
                    key={index}
                    className="mt-10 p-4 bg-[#E8F0E8]/50 border border-[#D5E3D5] rounded text-xs text-[#5C564E] leading-relaxed"
                  >
                    {para.text}
                  </div>
                );
              }

              return (
                <p key={index} className="text-[#38332C] leading-relaxed">
                  {para.text}
                </p>
              );
            })}
          </div>

          {/* Keywords & Classification (Unboxed metadata, zero-pill rule) */}
          <div className="pt-8 border-t border-[#E5DFD5] space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#14532D]">
              Research Keywords:
            </span>
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C564E]">
              {activeArticle.keywords.map((kw, i) => (
                <React.Fragment key={kw}>
                  <span>{kw}</span>
                  {i < activeArticle.keywords.length - 1 && (
                    <span aria-hidden="true" className="text-[#8C8275]">·</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Next / Previous Read Recommendations */}
          <div className="pt-8 border-t border-[#E5DFD5] space-y-4">
            <h4 className="font-serif text-xl font-medium text-[#14532D]">
              More Research Notes
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {JOURNAL_ARTICLES.filter((a) => a.id !== activeArticle.id).map((other) => (
                <div
                  key={other.id}
                  onClick={() => handleSelectArticle(other)}
                  className="p-4 bg-[#F4EFE6] rounded border border-[#E5DFD5] hover:border-[#14532D] cursor-pointer transition-colors space-y-2 group"
                >
                  <div className="text-[11px] text-[#7B9B7B] font-medium">
                    {other.category} · {other.readTime}
                  </div>
                  <h5 className="font-serif text-base font-medium text-[#14532D] group-hover:underline line-clamp-2">
                    {other.title}
                  </h5>
                </div>
              ))}
            </div>
          </div>

        </article>
      ) : (
        /* Article Listing View */
        <div className="space-y-12">
          
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              <span>Editorial & Field Notes</span>
              <span aria-hidden="true">·</span>
              <span>Open Engineering</span>
            </div>
            <h1 className="font-serif text-4xl sm:text-5xl font-medium tracking-tight text-[#14532D]">
              The Studio Journal
            </h1>
            <p className="text-base sm:text-lg text-[#5C564E] leading-relaxed">
              Articles and engineering dispatches from our workshop in Dhaka. We explore fiber mechanics, pre-consumer waste sorting realities, and the imperative for verifiable sustainability metrics.
            </p>
          </div>

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {JOURNAL_ARTICLES.map((article) => (
              <div
                key={article.id}
                className="bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] overflow-hidden flex flex-col justify-between hover:border-[#14532D]/40 transition-all shadow-xs group"
              >
                <div>
                  {article.image && (
                    <div className="border-b border-[#E5DFD5]">
                      <TextileImage
                        src={article.image}
                        alt={article.title}
                        aspectRatioClass="aspect-[16/10]"
                        fallbackTitle={article.title}
                        fallbackCategory={article.category}
                      />
                    </div>
                  )}

                  <div className="p-6 sm:p-8 space-y-4">
                    <div className="flex items-center gap-2 text-xs text-[#5C564E]">
                      <span className="font-semibold text-[#14532D] uppercase tracking-wider">{article.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{article.readTime}</span>
                    </div>

                    <h3 className="font-serif text-2xl font-medium text-[#14532D] group-hover:text-[#0D381E] transition-colors leading-snug">
                      {article.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-[#5C564E] leading-relaxed line-clamp-3">
                      {article.abstract}
                    </p>

                    <div className="text-xs text-[#8C8275] pt-2">
                      {article.date} · {article.author}
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-[#E5DFD5] mt-6">
                  <button
                    onClick={() => handleSelectArticle(article)}
                    className="cursor-pointer inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E] group-hover:translate-x-0.5 transition-all"
                  >
                    <span>Read Full Note</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Research Note Contribution / Inquiry */}
          <div className="p-8 bg-[#F4EFE6] rounded border border-[#E5DFD5] flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="font-serif text-xl font-medium text-[#14532D]">
                Interested in publishing research with GreenThread?
              </h4>
              <p className="text-xs sm:text-sm text-[#5C564E]">
                We welcome co-authored articles on sustainable textile processing and local waste characterization.
              </p>
            </div>
            <button
              onClick={() => onNavigate('contact')}
              className="cursor-pointer px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors whitespace-nowrap"
            >
              Submit an Abstract
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
