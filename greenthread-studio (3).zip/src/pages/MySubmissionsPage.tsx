import React, { useState, useEffect } from 'react';
import { PageId, IdeaSubmission, SubmissionStatus } from '../types';
import { useAuth } from '../context/AuthContext';
import { submissionService } from '../services/submissionService';
import {
  Inbox,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  Link2,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Tag,
  Calendar,
  MessageSquare,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';

interface MySubmissionsPageProps {
  onNavigate: (page: PageId) => void;
}

export const MySubmissionsPage: React.FC<MySubmissionsPageProps> = ({ onNavigate }) => {
  const { user, isConfigured, openAuthModal } = useAuth();

  const [submissions, setSubmissions] = useState<IdeaSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Claim modal state
  const [claimTokenInput, setClaimTokenInput] = useState('');
  const [claimLoading, setClaimLoading] = useState(false);
  const [claimError, setClaimError] = useState<string | null>(null);
  const [claimSuccess, setClaimSuccess] = useState<string | null>(null);
  const [claimModalOpen, setClaimModalOpen] = useState(false);

  // Expanded items state
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchSubmissions = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await submissionService.getUserSubmissions(user.uid);
      setSubmissions(data);
    } catch (err: any) {
      console.error(err);
      setError('Unable to load your submissions. Please ensure Firestore is initialized.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, [user]);

  const handleClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setClaimError(null);
    setClaimSuccess(null);

    if (!claimTokenInput.trim()) {
      setClaimError('Please enter your submission reference token.');
      return;
    }

    try {
      setClaimLoading(true);
      const claimed = await submissionService.claimGuestSubmission(claimTokenInput.trim(), user);
      setClaimSuccess(`Successfully linked "${claimed.title}" to your account!`);
      setClaimTokenInput('');
      fetchSubmissions();
    } catch (err: any) {
      console.error(err);
      setClaimError(err.message || 'Failed to claim submission.');
    } finally {
      setClaimLoading(false);
    }
  };

  const getStatusBadge = (status: SubmissionStatus) => {
    switch (status) {
      case 'received':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#F4EFE6] text-[#8C6D23] border border-[#E5DFD5]">
            <Clock className="w-3.5 h-3.5" />
            <span>Received</span>
          </span>
        );
      case 'under_review':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#E8F0E8] text-[#14532D] border border-[#D5E3D5]">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Under Review</span>
          </span>
        );
      case 'prototype_evaluation':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#14532D] text-white">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Prototype Evaluation</span>
          </span>
        );
      case 'archived':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-stone-100 text-stone-600 border border-stone-200">
            <span>Archived</span>
          </span>
        );
      default:
        return null;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'reclaimed_fabrics':
        return 'Reclaimed Mill Remnants';
      case 'natural_fibers':
        return 'Indigenous Bast Fibers';
      case 'circular_design':
        return 'Circular Design & Disassembly';
      case 'dyeing_finishing':
        return 'Natural Finishing';
      default:
        return 'Textile Engineering';
    }
  };

  // Signed out view
  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg p-8 sm:p-12 text-center space-y-6 shadow-xs">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#E8F0E8] text-[#14532D] flex items-center justify-center">
            <Inbox className="w-7 h-7" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h2 className="font-serif text-3xl font-medium text-[#14532D]">
              Sign In to View Your Submissions
            </h2>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              Your submissions dashboard is private. Please authenticate to track review progress, view studio engineering notes, and link prior guest ideas.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => openAuthModal('signin')}
              className="cursor-pointer w-full sm:w-auto px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors shadow-xs"
            >
              Sign In to Account
            </button>
            <button
              onClick={() => openAuthModal('signup')}
              className="cursor-pointer w-full sm:w-auto px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
            >
              Create Free Account
            </button>
          </div>

          <div className="pt-6 border-t border-[#E5DFD5] text-xs text-[#8C8275]">
            Submitted an idea as a guest? You can securely link it immediately after signing in.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5DFD5] pb-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
            <span>Account Dashboard</span>
            <span aria-hidden="true">·</span>
            <span>{user.email}</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-medium text-[#14532D]">
            My Textile Submissions
          </h1>
          <p className="text-xs sm:text-sm text-[#5C564E]">
            Track the status of your submitted concepts in the GreenThread Studio review pipeline.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setClaimModalOpen(true)}
            className="cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#F4EFE6] hover:bg-[#EAE4D9] rounded border border-[#E5DFD5] transition-colors"
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Link Guest Idea</span>
          </button>

          <button
            onClick={() => onNavigate('submit-idea')}
            className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-all shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Submission</span>
          </button>
        </div>
      </div>

      {/* Claim Guest Submission Modal */}
      {claimModalOpen && (
        <div className="p-6 bg-[#FBF9F5] border border-[#14532D]/30 rounded-lg shadow-sm space-y-4 animate-in fade-in">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <h3 className="font-serif text-xl font-medium text-[#14532D] flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#7B9B7B]" />
                Link a Prior Guest Submission
              </h3>
              <p className="text-xs text-[#5C564E]">
                Enter the secret Reference Token (e.g., <code className="font-mono bg-white px-1 py-0.5 rounded border border-[#E5DFD5]">GT-XXXXXX</code>) provided when you submitted an idea without an account.
              </p>
            </div>
            <button
              onClick={() => {
                setClaimModalOpen(false);
                setClaimError(null);
                setClaimSuccess(null);
              }}
              className="text-xs text-[#8C8275] hover:text-[#14532D] underline cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {claimError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded text-xs text-red-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{claimError}</span>
            </div>
          )}

          {claimSuccess && (
            <div className="p-3 bg-green-50 border border-green-200 rounded text-xs text-green-800 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
              <span>{claimSuccess}</span>
            </div>
          )}

          <form onSubmit={handleClaim} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              required
              value={claimTokenInput}
              onChange={(e) => setClaimTokenInput(e.target.value)}
              placeholder="e.g. GT-A1B2C3D4E5F6G7H8"
              className="flex-1 px-3.5 py-2 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] font-mono focus:outline-none focus:border-[#14532D]"
            />
            <button
              type="submit"
              disabled={claimLoading}
              className="cursor-pointer px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] disabled:opacity-60 rounded transition-colors whitespace-nowrap"
            >
              {claimLoading ? 'Verifying...' : 'Verify & Link'}
            </button>
          </form>

          <p className="text-[11px] text-[#8C8275]">
            * Security guarantee: The submission must have been filed using your current account email (<strong>{user.email}</strong>).
          </p>
        </div>
      )}

      {/* Submissions List */}
      {loading ? (
        <div className="p-12 text-center text-xs text-[#5C564E] space-y-2">
          <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#14532D]" />
          <p>Loading your submissions from Firestore...</p>
        </div>
      ) : error ? (
        <div className="p-6 bg-red-50 border border-red-200 rounded text-xs text-red-800 space-y-2">
          <div className="font-semibold flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4" />
            <span>Connection Error</span>
          </div>
          <p>{error}</p>
        </div>
      ) : submissions.length === 0 ? (
        <div className="p-12 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg text-center space-y-4">
          <div className="w-12 h-12 mx-auto rounded-full bg-[#F4EFE6] text-[#7B9B7B] flex items-center justify-center">
            <Inbox className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="font-serif text-xl font-medium text-[#14532D]">
              No Submissions Linked Yet
            </h3>
            <p className="text-xs text-[#5C564E] max-w-sm mx-auto">
              You haven't submitted any ideas while signed in, or linked any prior guest concepts.
            </p>
          </div>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('submit-idea')}
              className="cursor-pointer px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors shadow-xs"
            >
              Submit an Idea
            </button>
            <button
              onClick={() => setClaimModalOpen(true)}
              className="cursor-pointer px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
            >
              Link Guest Concept
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-xs text-[#7B9B7B] font-medium">
            Showing {submissions.length} submission{submissions.length === 1 ? '' : 's'}
          </div>

          <div className="space-y-3">
            {submissions.map((sub) => {
              const isExpanded = expandedId === sub.id;
              const formattedDate = new Date(sub.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              });

              return (
                <div
                  key={sub.id}
                  className="bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg overflow-hidden transition-all shadow-2xs hover:border-[#14532D]/40"
                >
                  <div
                    onClick={() => setExpandedId(isExpanded ? null : sub.id)}
                    className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                  >
                    <div className="space-y-1.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C564E]">
                        <span className="text-[#14532D] font-medium flex items-center gap-1">
                          <Tag className="w-3 h-3 text-[#7B9B7B]" />
                          {getCategoryLabel(sub.category)}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#7B9B7B]" />
                          {formattedDate}
                        </span>
                      </div>

                      <h3 className="font-serif text-xl font-medium text-[#14532D] truncate">
                        {sub.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                      {getStatusBadge(sub.status)}
                      <div className="p-1 text-[#8C8275] hover:text-[#14532D]">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-[#E5DFD5] space-y-4 bg-[#F4EFE6]/40 text-xs text-[#2D312E] animate-in fade-in">
                      <div className="space-y-1">
                        <span className="font-semibold uppercase tracking-wider text-[#14532D] text-[11px]">
                          Concept Description:
                        </span>
                        <p className="text-sm text-[#4A453E] leading-relaxed whitespace-pre-wrap">
                          {sub.description}
                        </p>
                      </div>

                      {/* Admin Assessment Notes if present */}
                      {sub.adminNotes && (
                        <div className="p-4 bg-[#E8F0E8] border border-[#D5E3D5] rounded space-y-1">
                          <div className="font-semibold text-[#14532D] flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>GreenThread Studio Engineering Feedback</span>
                          </div>
                          <p className="text-xs text-[#2D312E] leading-relaxed">
                            {sub.adminNotes}
                          </p>
                        </div>
                      )}

                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#8C8275] border-t border-[#E5DFD5]">
                        <div>Reference Token: <span className="font-mono text-[#14532D]">{sub.claimToken}</span></div>
                        <div>Submitted under: {sub.email}</div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
};
