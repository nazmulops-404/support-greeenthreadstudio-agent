import React, { useState } from 'react';
import { PageId } from '../types';
import { Mail, MapPin, Globe, Send, AlertTriangle, CheckCircle, RefreshCw, MessageSquare, MessageCircle, Copy, Check, ArrowUpRight, ShieldAlert } from 'lucide-react';

interface ContactPageProps {
  onNavigate: (page: PageId) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    inquiryType: 'Research Collaboration',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);

  const rawPhone = '+8801919863846';
  const displayPhone = '+880 1919-863846';
  const whatsappUrl = `https://wa.me/8801919863846?text=${encodeURIComponent(
    'Hello GreenThread Studio Inc., I am reaching out regarding sustainable textile research and inquiries.'
  )}`;

  const handleCopyPhone = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(rawPhone);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email format (e.g. name@domain.com).';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Please specify an inquiry subject.';
    if (!formData.message.trim() || formData.message.trim().length < 15) {
      newErrors.message = 'Please provide at least 15 characters describing your inquiry.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    // Simulate frontend validation response
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      organization: '',
      inquiryType: 'Research Collaboration',
      subject: '',
      message: '',
    });
    setErrors({});
    setSubmitted(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      
      {/* Editorial Header with Official Brand Logo */}
      <div className="max-w-3xl space-y-4">
        <div className="flex items-center gap-4">
          <img
            src="/images/logo.jpg"
            alt="GreenThread Studio Inc. Logo"
            className="h-16 w-16 sm:h-20 sm:w-20 rounded-full object-contain bg-white border border-[#14532D]/20 p-1 shadow-sm shrink-0"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/assets/aistudio/iZqx5jgZ2fFL5zTQa_i632ncu-ulOcxgsElkkvHaPM0-zlXKWbm-ewhveMp48DNkC8iMC2zvnG_YWOMj8m8TQ5zphbB7DNXcrJOSsls8pmUnNPtqWs_WuHD6PUdN5dKuII7zei2WTY85kv7gZ8A6Tg5AQDMH5DEEoVthqwvpoyUcVapHyU-IwM47zfDgOwSJ_4457485d.jpg';
            }}
          />
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              <span>Get in Touch</span>
              <span aria-hidden="true">·</span>
              <span>Studio & Material Exchange</span>
            </div>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-medium tracking-tight text-[#14532D]">
              Contact GreenThread Studio Inc.
            </h1>
          </div>
        </div>
        <p className="text-base sm:text-lg text-[#5C564E] leading-relaxed pt-2">
          We welcome dialogue with textile researchers, circular economy practitioners, artisanal weavers, and potential material collaborators. For direct inquiries, communicate with our Dhaka workshop exclusively via WhatsApp text messaging.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
        
        {/* Left Column: WhatsApp Card & Studio Info */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Dedicated WhatsApp Official Text Channel Card */}
          <div className="p-6 bg-linear-to-br from-[#F4EFE6] to-[#E8F0E8] rounded-lg border-2 border-[#14532D]/20 shadow-xs space-y-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#25D366]/15 text-[#0F5132] text-[11px] font-semibold uppercase tracking-wider border border-[#25D366]/30">
                  <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
                  <span>WhatsApp Inquiries</span>
                </div>
                <h3 className="font-serif text-2xl font-semibold text-[#14532D]">
                  Text via WhatsApp
                </h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-xs shrink-0">
                <MessageCircle className="w-6 h-6" />
              </div>
            </div>

            {/* Phone Number Display */}
            <div className="p-3.5 bg-white rounded border border-[#D5E3D5] space-y-2">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#5C564E]">
                Official Contact Number
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xl sm:text-2xl font-bold text-[#14532D] tracking-tight">
                  {displayPhone}
                </span>
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="cursor-pointer inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded border border-[#E5DFD5] hover:bg-[#F4EFE6] text-[#5C564E] transition-colors"
                  title="Copy contact number"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#14532D]" />
                      <span className="text-[#14532D]">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#8C8275]" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Critical Policy Notice: WhatsApp Text Only */}
            <div className="p-3 bg-[#FFFBEB] rounded border border-[#FDE68A] text-xs text-[#92400E] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-[#78350F]">
                <ShieldAlert className="w-4 h-4 text-[#B45309] shrink-0" />
                <span>Text / Messaging Only Notice:</span>
              </div>
              <p className="leading-relaxed">
                Please note that this number is designated <strong>strictly for WhatsApp text and chat communication</strong>. Voice/cellular calls are disabled on this line and cannot be received. Please send your inquiries as a WhatsApp text or voice message.
              </p>
            </div>

            {/* Direct WhatsApp Action Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="cursor-pointer w-full py-3 px-4 rounded bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-xs transition-all hover:shadow-md"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Start WhatsApp Chat ({displayPhone})</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
          
          {/* General Studio Information Card */}
          <div className="p-6 bg-[#FBF9F5] rounded-lg border border-[#E5DFD5] space-y-6">
            <h3 className="font-serif text-2xl font-medium text-[#14532D]">
              Studio Information
            </h3>
            
            <div className="space-y-4 text-sm text-[#4A453E]">
              
              {/* WhatsApp Listing */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-medium text-[#14532D] text-xs uppercase tracking-wider">
                  <MessageSquare className="w-4 h-4 text-[#25D366]" />
                  <span>WhatsApp Contact (Text Only)</span>
                </div>
                <div className="pl-6 text-xs text-[#2D312E] bg-[#F4EFE6] p-2.5 rounded border border-[#E5DFD5] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-semibold text-sm text-[#14532D]">{displayPhone}</span>
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-[#14532D] hover:underline"
                    >
                      Chat now &rarr;
                    </a>
                  </div>
                  <div className="text-[10px] text-[#8C8275]">
                    WhatsApp chat/text communication only &bull; No direct telephone calls
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-medium text-[#14532D] text-xs uppercase tracking-wider">
                  <Mail className="w-4 h-4 text-[#7B9B7B]" />
                  <span>General & Research Inquiries</span>
                </div>
                <div className="pl-6 font-mono text-xs text-[#2D312E] bg-[#F4EFE6] p-2 rounded border border-[#E5DFD5]">
                  contact@greenthreadstudio.example
                  <div className="text-[10px] text-[#8C8275] font-sans pt-1">
                    [Editable contact email placeholder]
                  </div>
                </div>
              </div>

              {/* Location */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-medium text-[#14532D] text-xs uppercase tracking-wider">
                  <MapPin className="w-4 h-4 text-[#7B9B7B]" />
                  <span>Workshop & Studio Location</span>
                </div>
                <div className="pl-6 text-xs text-[#2D312E] bg-[#F4EFE6] p-2 rounded border border-[#E5DFD5] space-y-0.5">
                  <p className="font-medium">GreenThread Studio Inc. Lab</p>
                  <p>Road 11, Banani / Gulshan, Dhaka 1212</p>
                  <p>Dhaka, Bangladesh</p>
                  <div className="text-[10px] text-[#8C8275] pt-1">
                    [Editable physical address placeholder]
                  </div>
                </div>
              </div>

              {/* Social Placeholders */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-medium text-[#14532D] text-xs uppercase tracking-wider">
                  <Globe className="w-4 h-4 text-[#7B9B7B]" />
                  <span>Community & Code Repositories</span>
                </div>
                <div className="pl-6 text-xs text-[#2D312E] bg-[#F4EFE6] p-2.5 rounded border border-[#E5DFD5] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span>LinkedIn:</span>
                    <span className="font-mono text-[#8C8275]">linkedin.com/company/greenthread-studio [Placeholder]</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Instagram:</span>
                    <span className="font-mono text-[#8C8275]">@greenthread.studio [Placeholder]</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>GitHub:</span>
                    <span className="font-mono text-[#8C8275]">github.com/greenthread-studio [Placeholder]</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Research Collaboration Notice */}
          <div className="p-6 bg-[#E8F0E8] rounded-lg border border-[#D5E3D5] space-y-2 text-xs text-[#2D312E] leading-relaxed">
            <h4 className="font-serif text-lg font-medium text-[#14532D]">
              Open for Academic Sample Exchange
            </h4>
            <p className="text-[#5C564E]">
              We frequently dispatch small swatches of our handloom jute-cotton trials to material science faculties, textile engineering universities, and circular design students studying South Asian natural bast fibers.
            </p>
          </div>

        </div>

        {/* Right Column: Contact Form UI */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Direct WhatsApp Quick Connect Banner */}
          <div className="p-4 bg-[#E8F0E8] border border-[#25D366]/40 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#25D366] text-white flex items-center justify-center shrink-0 shadow-xs">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="text-xs text-[#2D312E]">
                <div className="font-semibold text-[#14532D]">Quick WhatsApp Text Communication</div>
                <div className="text-[#5C564E]">
                  Text directly at <strong className="font-mono text-[#14532D]">{displayPhone}</strong> (WhatsApp text only).
                </div>
              </div>
            </div>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#25D366] hover:bg-[#20ba59] rounded transition-colors shadow-xs"
            >
              <span>Open WhatsApp</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="bg-[#FBF9F5] p-6 sm:p-8 rounded-lg border border-[#E5DFD5] shadow-xs space-y-6">
            
            {/* Nonfunctional UI Disclaimer Box */}
            <div className="p-4 bg-[#F4EFE6] rounded border border-[#D8D0C3] flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#8C6D23] shrink-0 mt-0.5" />
              <div className="text-xs text-[#5C564E] leading-relaxed space-y-1">
                <span className="font-semibold text-[#1C1917]">Front-End Demonstration Interface:</span>
                <p>
                  This contact form is a <strong>client-side prototype UI</strong>. It is not connected to a backend server, database, or email delivery provider (SMTP/API). Submitting the form will perform client-side validation and render an on-screen simulation without transmitting data.
                </p>
              </div>
            </div>

            {submitted ? (
              /* Success Confirmation Simulation */
              <div className="p-8 bg-[#E8F0E8] rounded border border-[#D5E3D5] text-center space-y-4 animate-in fade-in duration-300">
                <div className="w-12 h-12 mx-auto rounded-full bg-[#14532D] text-white flex items-center justify-center">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-medium text-[#14532D]">
                    Simulated Submission Successful
                  </h3>
                  <p className="text-xs sm:text-sm text-[#5C564E] max-w-md mx-auto">
                    Thank you, <strong>{formData.name}</strong>. In a live production deployment, this inquiry regarding "{formData.subject}" would be dispatched directly to the studio inbox.
                  </p>
                </div>

                <div className="p-4 bg-white/80 rounded border border-[#D5E3D5] max-w-md mx-auto text-left text-xs text-[#5C564E] space-y-1">
                  <div><strong>Name:</strong> {formData.name}</div>
                  <div><strong>Email:</strong> {formData.email}</div>
                  <div><strong>Inquiry Type:</strong> {formData.inquiryType}</div>
                  <div><strong>Organization:</strong> {formData.organization || 'Not specified'}</div>
                  <div><strong>Message Length:</strong> {formData.message.length} characters</div>
                </div>

                <button
                  onClick={handleReset}
                  className="cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Send Another Simulated Inquiry</span>
                </button>
              </div>
            ) : (
              /* Interactive Form UI */
              <form onSubmit={handleSubmit} className="space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="space-y-1">
                    <label htmlFor="name" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Your Name <span className="text-[#8C6D23]">*</span>
                    </label>
                    <input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Dr. Sabrina Ahmed"
                      className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                    />
                    {errors.name && <p className="text-[11px] text-red-600">{errors.name}</p>}
                  </div>

                  {/* Email */}
                  <div className="space-y-1">
                    <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Email Address <span className="text-[#8C6D23]">*</span>
                    </label>
                    <input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. sabrina@university.edu"
                      className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                    />
                    {errors.email && <p className="text-[11px] text-red-600">{errors.email}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Organization */}
                  <div className="space-y-1">
                    <label htmlFor="organization" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Organization / University <span className="text-[#8C8275] font-normal">(Optional)</span>
                    </label>
                    <input
                      id="organization"
                      type="text"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      placeholder="e.g. BUTEX / Independent Design"
                      className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                    />
                  </div>

                  {/* Inquiry Type */}
                  <div className="space-y-1">
                    <label htmlFor="inquiryType" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Inquiry Focus
                    </label>
                    <select
                      id="inquiryType"
                      value={formData.inquiryType}
                      onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                    >
                      <option value="Research Collaboration">Academic / Research Collaboration</option>
                      <option value="Prototype Testing">Prototype Swatch & Tensile Testing</option>
                      <option value="Material Sourcing">Pre-Consumer Fabric Scrap Supply</option>
                      <option value="Artisan Partnership">Handloom Artisan Exchange</option>
                      <option value="General Dialogue">General Inquiries</option>
                    </select>
                  </div>
                </div>

                {/* Subject */}
                <div className="space-y-1">
                  <label htmlFor="subject" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                    Subject Line <span className="text-[#8C6D23]">*</span>
                  </label>
                  <input
                    id="subject"
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g. Inquiry regarding Jute-Cotton blend GT-P01 swatch specs"
                    className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                  />
                  {errors.subject && <p className="text-[11px] text-red-600">{errors.subject}</p>}
                </div>

                {/* Message */}
                <div className="space-y-1">
                  <label htmlFor="message" className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                    Message <span className="text-[#8C6D23]">*</span>
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your inquiry, research focus, or questions about our development prototypes..."
                    className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors resize-y"
                  />
                  {errors.message && <p className="text-[11px] text-red-600">{errors.message}</p>}
                </div>

                {/* Submit button */}
                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[11px] text-[#8C8275]">
                    * Marked fields are required
                  </span>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] disabled:opacity-60 rounded transition-all shadow-xs"
                  >
                    {submitting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Validating...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Simulate Message Send</span>
                      </>
                    )}
                  </button>
                </div>

              </form>
            )}

          </div>
        </div>

      </div>

    </div>
  );
};
