import React, { useState, useEffect } from 'react';
import { PageId, IdeaSubmission, SubmissionStatus, SubmissionCategory } from '../types';
import { useAuth } from '../context/AuthContext';
import { submissionService } from '../services/submissionService';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  RefreshCw,
  Edit3,
  X,
  MessageSquare,
  AlertCircle,
  Tag,
  Calendar,
  User,
  Mail,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface AdminDashboardPageProps {
  onNavigate: (page: PageId) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate }) => {
  const { user, isAdmin, loading: authLoading, openAuthModal } = useAuth();

  const [submissions, setSubmissions] = useState<IdeaSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters & Search
  const [statusFilter, setStatusFilter] = useState<'all' | SubmissionStatus>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | SubmissionCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Editing state
  const [editingSub, setEditingSub] = useState<IdeaSubmission | null>(null);
  const [editStatus, setEditStatus] = useState<SubmissionStatus>('received');
  const [editNotes, setEditNotes] = useState('');
  const [saveLoading, setSaveLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  // Expanded items
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchAdminSubmissions = async () => {
    if (!isAdmin) return;
    setLoading(true);
    setError(null);
    try {
      const data = await submissionService.getAllSubmissionsAdmin();
      setSubmissions(data);
    } catch (err: any) {
      console.error(err);
      setError('Failed to fetch submissions. You must be an authorized administrator in Firestore security rules.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAdminSubmissions();
    } else {
      setLoading(false);
    }
  }, [isAdmin]);

  const handleOpenEdit = (sub: IdeaSubmission) => {
    setEditingSub(sub);
    setEditStatus(sub.status);
    setEditNotes(sub.adminNotes || '');
    setSaveSuccess(null);
  };

  const handleSaveStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSub) return;

    try {
      setSaveLoading(true);
      await submissionService.updateSubmissionStatusAdmin(
        editingSub.id,
        editStatus,
        editNotes
      );
      setSaveSuccess('Status and notes updated successfully.');
      // Update local state
      setSubmissions((prev) =>
        prev.map((s) =>
          s.id === editingSub.id
            ? { ...s, status: editStatus, adminNotes: editNotes.trim(), updatedAt: new Date().toISOString() }
            : s
        )
      );
      setTimeout(() => {
        setEditingSub(null);
        setSaveSuccess(null);
      }, 1200);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Permission denied: Could not update submission in Firestore.');
    } finally {
      setSaveLoading(false);
    }
  };

  // Filtered submissions
  const filteredSubmissions = submissions.filter((sub) => {
    if (statusFilter !== 'all' && sub.status !== statusFilter) return false;
    if (categoryFilter !== 'all' && sub.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = sub.title.toLowerCase().includes(q);
      const matchName = sub.name.toLowerCase().includes(q);
      const matchEmail = sub.email.toLowerCase().includes(q);
      const matchToken = sub.claimToken.toLowerCase().includes(q);
      if (!matchTitle && !matchName && !matchEmail && !matchToken) return false;
    }
    return true;
  });

  const getStatusBadge = (status: SubmissionStatus) => {
    switch (status) {
      case 'received':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#F4EFE6] text-[#8C6D23] border border-[#E5DFD5]">
            <Clock className="w-3.5 h-3.5" />
            <span>Received</span>
          </span>
        );
      case 'under_review':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#E8F0E8] text-[#14532D] border border-[#D5E3D5]">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Under Review</span>
          </span>
        );
      case 'prototype_evaluation':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-[#14532D] text-white">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Prototype Evaluation</span>
          </span>
        );
      case 'archived':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-stone-100 text-stone-600 border border-stone-200">
            <span>Archived</span>
          </span>
        );
      default:
        return null;
    }
  };

  // Access denied screen
  if (!authLoading && !isAdmin) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-[#FBF9F5] border border-red-200 rounded-lg p-8 sm:p-12 text-center space-y-6 shadow-xs">
          <div className="w-14 h-14 mx-auto rounded-full bg-red-100 text-red-700 flex items-center justify-center">
            <ShieldAlert className="w-7 h-7" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h2 className="font-serif text-3xl font-medium text-[#14532D]">
              Administrator Authorization Required
            </h2>
            <p className="text-sm text-[#5C564E] leading-relaxed">
              This dashboard is restricted to authorized studio personnel. Backend Firestore Security Rules strictly prohibit unauthorized read and update access.
            </p>
          </div>

          {!user ? (
            <div className="pt-2">
              <button
                onClick={() => openAuthModal('signin')}
                className="cursor-pointer px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-colors shadow-xs"
              >
                Sign In with Administrator Account
              </button>
            </div>
          ) : (
            <div className="p-4 bg-[#F4EFE6] rounded text-xs text-[#5C564E] max-w-md mx-auto space-y-1">
              <div>Currently signed in as: <strong>{user.email}</strong></div>
              <p className="text-[11px] text-[#8C8275]">
                To grant admin access, add this UID to the <code className="font-mono">admins</code> collection in Firestore or sign in with the designated bootstrap administrator.
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5DFD5] pb-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#14532D]">
            <ShieldCheck className="w-4 h-4 text-[#7B9B7B]" />
            <span>Authorized Administrator Console</span>
            <span aria-hidden="true">·</span>
            <span>{user?.email}</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-medium text-[#14532D]">
            Studio Submission Management
          </h1>
          <p className="text-xs sm:text-sm text-[#5C564E]">
            Review all incoming ideas, change evaluation statuses, and record technical assessment notes.
          </p>
        </div>

        <button
          onClick={fetchAdminSubmissions}
          disabled={loading}
          className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg">
          <div className="text-xs text-[#8C8275] uppercase tracking-wider">Total Submissions</div>
          <div className="font-serif text-3xl font-medium text-[#14532D] mt-1">{submissions.length}</div>
        </div>
        <div className="p-4 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg">
          <div className="text-xs text-[#8C8275] uppercase tracking-wider">New (Received)</div>
          <div className="font-serif text-3xl font-medium text-[#8C6D23] mt-1">
            {submissions.filter((s) => s.status === 'received').length}
          </div>
        </div>
        <div className="p-4 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg">
          <div className="text-xs text-[#8C8275] uppercase tracking-wider">Under Review</div>
          <div className="font-serif text-3xl font-medium text-[#7B9B7B] mt-1">
            {submissions.filter((s) => s.status === 'under_review').length}
          </div>
        </div>
        <div className="p-4 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg">
          <div className="text-xs text-[#8C8275] uppercase tracking-wider">Prototype Trials</div>
          <div className="font-serif text-3xl font-medium text-[#14532D] mt-1">
            {submissions.filter((s) => s.status === 'prototype_evaluation').length}
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="p-4 bg-[#F4EFE6] border border-[#E5DFD5] rounded-lg flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#8C8275] absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, submitter name, email, or token..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D]"
          >
            <option value="all">All Statuses</option>
            <option value="received">Received</option>
            <option value="under_review">Under Review</option>
            <option value="prototype_evaluation">Prototype Evaluation</option>
            <option value="archived">Archived</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="px-3 py-2 text-xs bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D]"
          >
            <option value="all">All Categories</option>
            <option value="reclaimed_fabrics">Reclaimed Fabrics</option>
            <option value="natural_fibers">Natural Bast Fibers</option>
            <option value="circular_design">Circular Design</option>
            <option value="dyeing_finishing">Natural Finishing</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      {/* Submissions Table / Cards */}
      {loading ? (
        <div className="p-12 text-center text-xs text-[#5C564E] space-y-2">
          <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#14532D]" />
          <p>Fetching all submissions from Firestore...</p>
        </div>
      ) : error ? (
        <div className="p-6 bg-red-50 border border-red-200 rounded text-xs text-red-800 space-y-2">
          <div className="font-semibold flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4" />
            <span>Authorization Error</span>
          </div>
          <p>{error}</p>
        </div>
      ) : filteredSubmissions.length === 0 ? (
        <div className="p-12 bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg text-center space-y-2 text-xs text-[#5C564E]">
          <p>No submissions match the selected filters or search query.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-xs text-[#7B9B7B] font-medium">
            Showing {filteredSubmissions.length} of {submissions.length} submissions
          </div>

          <div className="space-y-3">
            {filteredSubmissions.map((sub) => {
              const isExpanded = expandedId === sub.id;
              const formattedDate = new Date(sub.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={sub.id}
                  className="bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg overflow-hidden transition-all shadow-2xs hover:border-[#14532D]/40"
                >
                  <div className="p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1.5 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C564E]">
                        <span className="font-mono bg-[#EAE4D9] text-[#14532D] px-1.5 py-0.5 rounded text-[11px]">
                          {sub.claimToken}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#14532D] font-medium">{sub.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formattedDate}</span>
                        <span aria-hidden="true">·</span>
                        <span className={sub.ownerId ? 'text-[#14532D] font-medium' : 'text-[#8C8275]'}>
                          {sub.ownerId ? 'Linked to Account' : 'Guest Submission'}
                        </span>
                      </div>

                      <h3 className="font-serif text-xl font-medium text-[#14532D]">
                        {sub.title}
                      </h3>

                      <div className="text-xs text-[#5C564E] flex items-center gap-4 pt-0.5">
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-[#7B9B7B]" /> {sub.name}
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5 text-[#7B9B7B]" /> {sub.email}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                      {getStatusBadge(sub.status)}

                      <button
                        onClick={() => handleOpenEdit(sub)}
                        className="cursor-pointer inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Update</span>
                      </button>

                      <button
                        onClick={() => setExpandedId(isExpanded ? null : sub.id)}
                        className="p-1.5 text-[#8C8275] hover:text-[#14532D] cursor-pointer"
                        aria-label={isExpanded ? 'Collapse' : 'Expand'}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Description & Notes */}
                  {isExpanded && (
                    <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-[#E5DFD5] space-y-4 bg-[#F4EFE6]/40 text-xs text-[#2D312E] animate-in fade-in">
                      <div className="space-y-1">
                        <span className="font-semibold uppercase tracking-wider text-[#14532D] text-[11px]">
                          Idea Full Description:
                        </span>
                        <p className="text-sm text-[#4A453E] leading-relaxed whitespace-pre-wrap">
                          {sub.description}
                        </p>
                      </div>

                      {sub.adminNotes && (
                        <div className="p-4 bg-[#E8F0E8] border border-[#D5E3D5] rounded space-y-1">
                          <div className="font-semibold text-[#14532D] flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Recorded Studio Feedback</span>
                          </div>
                          <p className="text-xs text-[#2D312E] leading-relaxed">
                            {sub.adminNotes}
                          </p>
                        </div>
                      )}

                      <div className="text-[11px] text-[#8C8275] flex items-center justify-between pt-2 border-t border-[#E5DFD5]">
                        <span>Doc ID: <code className="font-mono">{sub.id}</code></span>
                        <span>Owner UID: <code className="font-mono">{sub.ownerId || 'null (Guest)'}</code></span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Status & Feedback Edit Modal */}
      {editingSub && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg max-w-lg w-full shadow-2xl relative overflow-hidden">
            
            <div className="px-6 py-5 border-b border-[#E5DFD5] flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#7B9B7B]">
                  Admin Status Update
                </span>
                <h3 className="font-serif text-xl font-medium text-[#14532D] truncate max-w-sm">
                  {editingSub.title}
                </h3>
              </div>
              <button
                onClick={() => setEditingSub(null)}
                className="p-1.5 text-[#5C564E] hover:text-[#14532D] rounded hover:bg-[#F4EFE6] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStatus} className="p-6 space-y-4">
              
              {saveSuccess && (
                <div className="p-3 bg-green-50 border border-green-200 rounded text-xs text-green-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>{saveSuccess}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Review Status
                </label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as SubmissionStatus)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D]"
                >
                  <option value="received">Received (Awaiting Initial Triage)</option>
                  <option value="under_review">Under Review (Material Assessment)</option>
                  <option value="prototype_evaluation">Prototype Evaluation (Loom / Sewing Trial)</option>
                  <option value="archived">Archived (Closed / Not Proceeding)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                  Studio Assessment Notes / Feedback
                </label>
                <textarea
                  rows={4}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Record engineering feedback, weave feasibility, or prototype testing notes. This will be visible to the submitter on their dashboard..."
                  className="w-full px-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] resize-y"
                />
              </div>

              <div className="pt-3 border-t border-[#E5DFD5] flex items-center justify-between">
                <span className="text-[11px] text-[#8C8275]">
                  Enforced via Firestore Security Rules
                </span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setEditingSub(null)}
                    className="cursor-pointer px-4 py-2 text-xs text-[#5C564E] hover:text-[#14532D]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saveLoading}
                    className="cursor-pointer px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] disabled:opacity-60 rounded transition-colors shadow-xs"
                  >
                    {saveLoading ? 'Saving...' : 'Save Updates'}
                  </button>
                </div>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
