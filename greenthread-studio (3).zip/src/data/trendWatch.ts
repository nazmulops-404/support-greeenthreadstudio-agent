import { TrendWatchItem } from '../types';

export const TREND_WATCH_ITEMS: TrendWatchItem[] = [
  {
    id: 'textile-exchange-materials-market-report',
    title: 'Materials Market Report: Global Fiber Production & Preferred Synthetics Trends',
    organization: 'Textile Exchange',
    publicationDate: 'November 2024',
    summary: 'Comprehensive statistical report documenting global fiber volume trends. While virgin polyester and fossil synthetics continue to dominate global volume, demand for preferred natural bast fibers (including jute, hemp, and flax) and certified organic cotton shows gradual growth in specialized decentralized sectors.',
    sourceUrl: 'https://textileexchange.org/knowledge-center/reports/materials-market-report-2024/',
    isVerifiedSource: true,
    editorialNote: 'Verified original publication by Textile Exchange. Highlights the systemic need for regional bast fiber processing infrastructure in South Asia.',
    focusArea: 'Global Fiber Production'
  },
  {
    id: 'emf-new-textiles-economy',
    title: 'A New Textiles Economy: Redesigning Fashion’s Future',
    organization: 'Ellen MacArthur Foundation',
    publicationDate: 'November 2017',
    summary: 'The landmark circular economy framework analyzing structural linear waste in clothing production. Outlines key ambitions: phasing out substances of concern, increasing clothing utilization, radically improving recycling through design for disassembly, and making effective use of renewable resources.',
    sourceUrl: 'https://www.ellenmacarthurfoundation.org/a-new-textiles-economy',
    isVerifiedSource: true,
    editorialNote: 'Verified historical milestone paper. Serves as our guiding framework for eliminating permanent adhesive laminations in prototype carryalls.',
    focusArea: 'Circular Economy Architecture'
  },
  {
    id: 'eu-strategy-circular-textiles',
    title: 'EU Strategy for Sustainable and Circular Textiles',
    organization: 'European Commission',
    publicationDate: 'March 2022',
    summary: 'Key policy framework mandating mandatory Ecodesign requirements, Digital Product Passports (DPP), strict rules against greenwashing, and targets for textile durability, repairability, and recycled fiber content for goods entering the European market.',
    sourceUrl: 'https://environment.ec.europa.eu/strategy/textiles-strategy_en',
    isVerifiedSource: true,
    editorialNote: 'Verified European Union policy document. Directly influences our documentation standard and fiber traceability protocol.',
    focusArea: 'Regulatory & Trade Standards'
  },
  {
    id: 'fashion-for-good-sorting-circularity',
    title: 'Sorting for Circularity: Post-Consumer & Pre-Consumer Textile Waste Characterization',
    organization: 'Fashion for Good',
    publicationDate: 'October 2022',
    summary: 'Technical study evaluating optical and near-infrared sorting technologies to categorize blended textile offcuts. Emphasizes that high-elastane content (even at 2–3%) frequently chokes mechanical recycling garnetting machines.',
    sourceUrl: 'https://fashionforgood.com/our-programmes/sorting-for-circularity/',
    isVerifiedSource: true,
    editorialNote: 'Verified technical research study. Reinforces why GreenThread avoids blended elastane remnants in our initial offcut sourcing.',
    focusArea: 'Sorting & Recycling Technologies'
  },
  {
    id: 'placeholder-bangladesh-jute-mechanics',
    title: '[Upcoming Research Note Placeholder] Tensile Performance of Handloom Jute-Cotton Blends in Humid Monsoonal Climates',
    organization: 'GreenThread Studio & Regional Research Collaborators',
    publicationDate: 'Scheduled for Q4 2026 / Q1 2027 [Placeholder]',
    summary: 'Field data and tensile wear logs comparing handloom plain weave and herringbone patterns under cyclic tensile loads. Testing protocols and humidity chamber calibrations are currently in preparation.',
    sourceUrl: '#',
    isVerifiedSource: false,
    editorialNote: 'PLACEHOLDER: Verified experimental data is currently in collection. Formal peer-reviewed results and laboratory citations will be published here upon completion.',
    focusArea: 'Regional Materials Science'
  },
  {
    id: 'placeholder-community-rmg-survey',
    title: '[Field Survey Placeholder] Pre-Consumer Fabric Salvage Density across Narayanganj Textile Clusters',
    organization: 'GreenThread Studio Field Notes',
    publicationDate: 'In Fieldwork [Placeholder]',
    summary: 'A spatial map and qualitative audit of scrap fabric segregation practices at tier-2 knitwear finishing facilities in greater Dhaka.',
    sourceUrl: '#',
    isVerifiedSource: false,
    editorialNote: 'PLACEHOLDER: Pending publication following completion of initial studio sourcing agreements.',
    focusArea: 'Supply Chain Geography'
  }
];
