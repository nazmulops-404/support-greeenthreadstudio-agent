import { PrototypeItem } from '../types';

export const PROTOTYPES: PrototypeItem[] = [
  {
    id: 'everyday-carryall',
    code: 'GT-P01',
    name: 'Everyday Jute-Cotton Hybrid Carryall',
    category: 'bags',
    categoryLabel: 'Planned Reusable Bags',
    stage: 'Pattern Testing',
    developmentStatus: 'In Development — Iteration 02',
    shortDescription: 'A structured, unlined daily carryall utilizing high-tensile untreated jute weft blended with unbleached organic cotton warp.',
    fullDescription: 'Developed to replace petroleum-derived synthetic shopping and commuting bags. We are testing a 45/55 jute-to-cotton ratio to combine the tensile load-bearing capacity of natural bast fibers with the tactile softness and foldability of unbleached cotton.',
    fiberComposition: '45% Untreated Golden Jute / 55% Unbleached Cotton',
    weaveStructure: 'Heavyweight Plain Weave (estimated ~380 GSM)',
    dimensionsEstimated: '38 cm (W) × 42 cm (H) × 12 cm (Gusset)',
    primaryImage: '/images/prototype_jute_tote.jpg',
    secondaryDetails: [
      { label: 'Closure Mechanism', value: 'Open top with internal cotton key tether' },
      { label: 'Handle Construction', value: 'Double-folded cotton herringbone webbing' },
      { label: 'Seam Construction', value: 'Bound French seams (zero overlock synthetic threads)' },
      { label: 'End-of-Life Design', value: '100% plant-fiber assembly suitable for industrial composting' }
    ],
    researchObjectives: [
      'Evaluate fiber shedding and dust abrasion during repeat laundering',
      'Optimize handle attachment load distribution without synthetic buckram stiffeners',
      'Test handloom tension consistency between jute and cotton yarns'
    ],
    honestLimitation: 'Prototype stage only. No laboratory tear strength certification has been conducted yet; wear trials are ongoing in Dhaka.'
  },
  {
    id: 'selvedge-utility-pouch',
    code: 'GT-P02',
    name: 'Reclaimed Selvedge Denim & Canvas Pouch',
    category: 'accessories',
    categoryLabel: 'Reclaimed Fabric Accessories',
    stage: 'Sewing Trials',
    developmentStatus: 'In Development — Pattern Iteration 01',
    shortDescription: 'Compact utility zippered pouch assembled from post-industrial denim edge cuttings and natural canvas offcuts.',
    fullDescription: 'Bangladesh produces hundreds of metric tons of pre-consumer cutting-room selvedge strips weekly. This prototype explores modular strip-piecing techniques to turn narrow 8–12 cm scrap offcuts into durable zip containers for cables, stationery, and small tools.',
    fiberComposition: '100% Pre-Consumer Cotton Remnants (Indigo Denim & Natural Duck Canvas)',
    weaveStructure: '3/1 Right-Hand Twill combined with Heavy Canvas',
    dimensionsEstimated: '22 cm (W) × 15 cm (H) × 4 cm (Base)',
    primaryImage: '/images/reclaimed_fabric_pouch.jpg',
    secondaryDetails: [
      { label: 'Hardware', value: 'Brass pull zipper on unbleached cotton tape' },
      { label: 'Lining', value: 'Unlined interior with bound seam allowances' },
      { label: 'Sourcing Source', value: 'Pre-consumer cutting room remnants from regional export mills' },
      { label: 'Coloration', value: 'Original undyed canvas + factory mill indigo (no re-dyeing)' }
    ],
    researchObjectives: [
      'Determine standardized cutting templates to minimize secondary scrap in assembly',
      'Measure seam slippage on mixed-weight offcut junctures',
      'Assess non-toxic water-repellent wax coatings using local beeswax'
    ],
    honestLimitation: 'Prototype concept. Commercial volume requires stable factory offcut segregation partnerships which are currently being surveyed.'
  },
  {
    id: 'handloom-market-tote',
    code: 'GT-P03',
    name: 'Handloom Herringbone Utility Tote',
    category: 'bags',
    categoryLabel: 'Planned Reusable Bags',
    stage: 'Loom Setup',
    developmentStatus: 'In Development — Loom Tension Trial',
    shortDescription: 'Tactile daily tote exploring regional artisanal handloom weaving with natural golden jute yarns.',
    fullDescription: 'Handloom weaving allows lower mechanical tension on coarse jute fibers compared to automated air-jet looms, resulting in fewer fiber fractures and a softer hand-feel. This prototype is exploring traditional herringbone patterns to maximize lateral tear resistance.',
    fiberComposition: '50% Raw Indigenous Jute / 50% Mill-Offcut Cotton Yarn',
    weaveStructure: 'Broken Twill / Herringbone Weave (~320 GSM)',
    dimensionsEstimated: '35 cm (W) × 40 cm (H) × 10 cm (Gusset)',
    primaryImage: '/images/handloom_herringbone_tote.jpg',
    secondaryDetails: [
      { label: 'Weaving Method', value: 'Artisanal pit-loom / frame-loom pilot trial' },
      { label: 'Yarn Count', value: '6 lbs/spindle jute weft × 20s cotton warp' },
      { label: 'Handle Spec', value: 'Integrated self-fabric woven straps' },
      { label: 'Finish', value: 'Water-washed with cold river-sediment settling' }
    ],
    researchObjectives: [
      'Calibrate shrinkage rate after cold-water washing',
      'Examine warp breakage frequency during artisan shuttle passes',
      'Assess aesthetic variation between hand-spun yarn lots'
    ],
    honestLimitation: 'Early sample swatch stage. Not for sale; production batch consistency is not yet quantified.'
  },
  {
    id: 'modular-tech-sleeve',
    code: 'GT-P04',
    name: 'Compressed Scrap Felt Protective Sleeve',
    category: 'accessories',
    categoryLabel: 'Reclaimed Fabric Accessories',
    stage: 'Concept Specification',
    developmentStatus: 'In Development — Material Sampling',
    shortDescription: 'Padded laptop and document envelope replacing petrochemical foam with multi-layer compressed cotton-jute batting.',
    fullDescription: 'Modern protective sleeves rely almost universally on polyurethane foam, neoprene, or EVA foam laminations that render fabrics unrecyclable. We are testing needle-punched batting made from shredded apparel clippings sandwiched between dense canvas layers.',
    fiberComposition: 'Outer: 100% Recycled Cotton Twill; Core: Shredded Cotton/Jute Batting; Lining: Unbleached Muslin',
    weaveStructure: 'Quilted composite sandwich construction',
    dimensionsEstimated: '34 cm (W) × 25 cm (H) (Sized for 13–14" laptops)',
    primaryImage: '/images/modular_tech_sleeve.jpg',
    secondaryDetails: [
      { label: 'Closure', value: 'Natural coconut shell button and braided cotton cord' },
      { label: 'Impact Protection', value: 'Mechanical drop absorption testing in planning' },
      { label: 'Adhesive Layer', value: 'Zero lamination adhesives used; quilting holds batting' },
      { label: 'Material Origin', value: 'Post-industrial textile offcuts collected in Gazipur & Dhaka' }
    ],
    researchObjectives: [
      'Compare shock absorption of needle-punched cotton batting vs 4mm EVA foam',
      'Verify mold resistance in high-humidity monsoon conditions without synthetic fungicides',
      'Develop modular quilting patterns that can adjust to scrap remnant sizing'
    ],
    honestLimitation: 'Concept specification only. Cushioning testing has not yet been peer-reviewed or laboratory verified.'
  }
];
