import { JournalArticle } from '../types';

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'jute-cotton-blending-mechanics',
    slug: 'jute-cotton-blending-mechanics',
    title: 'Rethinking Jute in Everyday Goods: Mechanical Challenges and Blending Ratios with Cotton',
    subtitle: 'An examination of fiber brittleness, elongation at break, and warp-weft tension balancing in indigenous bast fiber applications.',
    author: 'Textile Research Notes — GreenThread Studio',
    date: 'August 14, 2026',
    readTime: '6 min read',
    category: 'Materials Engineering',
    image: '/images/hero_textile.jpg',
    abstract: 'Jute possesses extraordinary tensile strength and carbon sequestration benefits during cultivation, yet its brittleness and low elongation have historically relegated it to coarse gunny sacks. We examine how combining natural jute with long-staple cotton allows us to engineer supple, durable everyday textile structures.',
    contentParagraphs: [
      {
        type: 'paragraph',
        text: 'The industrial narrative around natural bast fibers often vacillates between uncritical romanticism and utilitarian dismissal. In Bangladesh, where jute (Corchorus olitorius and Corchorus capsularis) has supported agrarian livelihoods for centuries, the fiber is celebrated as the "Golden Fiber." Yet anyone who has handled commercial hessian knows its primary engineering limitations: high stiffness, fiber shed, roughness against bare skin, and low elongation at break (typically between 1.0% to 1.8%, compared to 7% to 10% for cotton).'
      },
      {
        type: 'paragraph',
        text: 'When designing an everyday carryall intended to survive five years of transit and grocery carrying, these mechanical properties present both opportunities and hurdles. Jute’s high initial modulus means a bag will not distort or sag under heavy vertical loads. However, sharp repetitive folds at the bag base create localized stress concentrations that lead to brittle fiber shear.'
      },
      {
        type: 'pullquote',
        text: 'A sustainable material must first and foremost be structurally durable. If an ecological bag fails at the handles after twenty uses, its net material efficiency collapses.'
      },
      {
        type: 'heading',
        text: 'Engineering the Warp and Weft Balance'
      },
      {
        type: 'paragraph',
        text: 'Our preliminary testing focuses on asymmetric hybrid constructions. Rather than carding and spinning an intimate fiber blend at the sliver stage—which requires specialized industrial spinning frames often unavailable for low-volume initiatives—we deploy unbleached cotton yarns for the warp (which endures high loom tension and friction during shedding) and single-ply raw jute yarn for the weft.'
      },
      {
        type: 'paragraph',
        text: 'By adjusting pick density and utilizing a 2/2 hopsack or balanced plain weave, the supple cotton wraps protect the brittle jute core. The result is a composite textile that retains the textural warmth and earthy rigidity of jute while offering the dimensional flexibility required for folded corners and seams.'
      },
      {
        type: 'heading',
        text: 'Open Questions for Upcoming Trials'
      },
      {
        type: 'paragraph',
        text: 'As we iterate through prototype batches, key parameters remain under observation: micro-fiber shed during repeated wet washing, the colorfastness of natural tannins, and the necessity of non-chemical mechanical softening (such as roller calendering).'
      },
      {
        type: 'footnote',
        text: 'Note: Ongoing research conducted at GreenThread Studio workshop in Dhaka. Results represent initial exploratory iterations and have not yet undergone certified ISO tensile lab validation.'
      }
    ],
    keywords: ['Jute Fiber', 'Textile Mechanics', 'Bast Fibers', 'Warp Weft Dynamics', 'Bangladesh Textiles']
  },
  {
    id: 'reality-pre-consumer-cutting-waste',
    slug: 'reality-pre-consumer-cutting-waste',
    title: 'The Reality of Pre-Consumer Cutting-Room Waste in Dhaka: Sourcing and Monomaterial Integrity',
    subtitle: 'Why the thousands of tons of garment remnants produced each month are far more complex to reclaim than marketing claims suggest.',
    author: 'Field Notes — GreenThread Studio',
    date: 'July 28, 2026',
    readTime: '8 min read',
    category: 'Circular Supply Chains',
    image: '/images/reclaimed_fabric_pouch.jpg',
    abstract: 'Dhaka’s ready-made garment (RMG) manufacturing clusters generate vast volumes of pre-consumer fabric scraps (jhoot). We detail the physical segregation obstacles, elastane contamination, and the imperative of designing modular products around irregular geometries.',
    contentParagraphs: [
      {
        type: 'paragraph',
        text: 'In global sustainability discourse, "upcycling textile waste" is frequently portrayed as an effortless triumph of creative design. The reality on the factory floors of Ashulia, Gazipur, and Narayanganj is considerably more nuanced. When automated cutting tables slice through hundreds of layers of fabric to produce T-shirts or denim jeans, between 10% and 20% of the material remains as cutting scraps, known locally as "jhoot."'
      },
      {
        type: 'paragraph',
        text: 'At first glance, this represents an inexhaustible goldmine for an early-stage studio. However, two primary technical challenges immediately emerge: fiber purity and dimensional consistency.'
      },
      {
        type: 'pullquote',
        text: 'True circularity requires honest material forensics. A fabric scrap labeled 100% cotton often contains elastane selvage blends or polyester sewing threads that hinder true biological cycling.'
      },
      {
        type: 'heading',
        text: 'The Elastane and Synthetic Contamination Problem'
      },
      {
        type: 'paragraph',
        text: 'Even in garments ostensibly marketed as pure cotton, selvedges and trim margins frequently harbor co-extruded elastane filaments or polyester stabilizers. If an initiative aims to manufacture biodegradable or mono-material accessories, accepting unsorted bundles from informal traders introduces uncontrollable material variance.'
      },
      {
        type: 'paragraph',
        text: 'Our approach at GreenThread Studio is to focus on specific, traceable waste streams: rigid 100% cotton selvedge denim cuttings and heavy unbleached duck canvas offcuts from workwear contracts. By limiting our pilot intake to known single-source remnants, we preserve the mechanical integrity of our GT-P02 pouch prototypes.'
      },
      {
        type: 'heading',
        text: 'Geometric Modularism: Designing for the Offcut Shape'
      },
      {
        type: 'paragraph',
        text: 'Rather than forcing irregular scraps into predetermined patterns—which generates secondary micro-waste—our pattern drafts use rectangular strip geometry derived from the narrow strips typical of cutting-room perimeter waste. Every cut made must justify itself.'
      },
      {
        type: 'footnote',
        text: 'Field observations compiled from visits to textile sorting yards in Mirpur and Gazipur. GreenThread Studio currently operates at prototype scale.'
      }
    ],
    keywords: ['Pre-consumer Waste', 'Jhoot', 'Dhaka RMG', 'Monomaterial Design', 'Textile Circularity']
  },
  {
    id: 'honest-lca-early-stage-initiatives',
    slug: 'honest-lca-early-stage-initiatives',
    title: 'Why Early-Stage Initiatives Must Avoid Premature LCA Claims',
    subtitle: 'The perils of publishing fabricated carbon savings and water offsets before primary supply chain data exists.',
    author: 'Methodology Brief — GreenThread Studio',
    date: 'June 19, 2026',
    readTime: '5 min read',
    category: 'Research Methodology',
    image: '/images/textile_research_loom.jpg',
    abstract: 'Life Cycle Assessment (LCA) has become the gold standard of environmental accountability, yet micro-studios routinely publish speculative numbers. Here is why GreenThread Studio refuses to print unverified impact metrics on our prototypes.',
    contentParagraphs: [
      {
        type: 'paragraph',
        text: 'Browse the website of almost any fledgling eco-fashion venture today, and you will encounter assertions such as: "Saves 2,400 liters of water per bag!" or "85% lower carbon footprint than conventional alternatives." To an engineer or researcher, these figures raise immediate red flags.'
      },
      {
        type: 'paragraph',
        text: 'A legitimate Life Cycle Assessment requires defined system boundaries (cradle-to-gate or cradle-to-grave), primary utility metering (kilowatt-hours of electricity used in spinning, fuel consumed in transport), and rigorous allocation methods for by-products. When an initiative is producing fifty prototype bags on a handloom in Dhaka, running a defensible ISO 14040/44 compliant LCA is not only cost-prohibitive—it is mathematically premature.'
      },
      {
        type: 'pullquote',
        text: 'Integrity in sustainable design means stating what you do not yet know, rather than substituting speculation for scientific measurement.'
      },
      {
        type: 'heading',
        text: 'Our Commitment to Descriptive Honesty'
      },
      {
        type: 'paragraph',
        text: 'At GreenThread Studio, we operate under a strict policy: we do not publish calculated metric savings until we have verified third-party primary data for each specific lot. Instead, we describe qualitative physical realities: the use of rain-fed, untreated fibers; the absence of toxic synthetic dyes; and the elimination of irreversible laminate adhesives.'
      },
      {
        type: 'paragraph',
        text: 'We invite researchers and LCA practitioners interested in primary data collection for South Asian decentralized handloom and reclaimed textile systems to collaborate with us.'
      },
      {
        type: 'footnote',
        text: 'Methodology adopted by GreenThread Studio advisory board, Dhaka, 2026.'
      }
    ],
    keywords: ['LCA', 'Life Cycle Assessment', 'Greenwashing Prevention', 'Scientific Transparency']
  }
];
