import React, { useState, useEffect } from 'react';
import { PageId } from './types';
import { AuthProvider } from './context/AuthContext';
import { AuthModal } from './components/AuthModal';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { NoticeBanner } from './components/NoticeBanner';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { PrototypesPage } from './pages/PrototypesPage';
import { JournalPage } from './pages/JournalPage';
import { TrendWatchPage } from './pages/TrendWatchPage';
import { ContactPage } from './pages/ContactPage';
import { SubmitIdeaPage } from './pages/SubmitIdeaPage';
import { MySubmissionsPage } from './pages/MySubmissionsPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [selectedPrototypeId, setSelectedPrototypeId] = useState<string | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);

  // Sync state with URL hash for browser back/forward and deep linking
  useEffect(() => {
    const parseHash = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      const validPages: PageId[] = [
        'home',
        'about',
        'prototypes',
        'journal',
        'trend-watch',
        'contact',
        'submit-idea',
        'my-submissions',
        'admin',
      ];
      
      if (validPages.includes(hash as PageId)) {
        setCurrentPage(hash as PageId);
      } else if (!hash) {
        setCurrentPage('home');
      }
    };

    parseHash();
    window.addEventListener('hashchange', parseHash);
    return () => window.removeEventListener('hashchange', parseHash);
  }, []);

  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
    window.location.hash = `#/${page}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectPrototype = (prototypeId: string) => {
    setSelectedPrototypeId(prototypeId);
    handleNavigate('prototypes');
  };

  const handleSelectArticle = (articleId: string) => {
    setSelectedArticleId(articleId);
    handleNavigate('journal');
  };

  return (
    <AuthProvider>
      <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#1C1917] selection:bg-[#87A987]/30 selection:text-[#14532D]">
        {/* Skip to Main Content Link for Accessibility */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 z-50 px-4 py-2 bg-[#14532D] text-white text-xs font-semibold uppercase tracking-wider rounded"
        >
          Skip to main content
        </a>

        {/* Transparent Early-Stage Studio Banner */}
        <NoticeBanner />

        {/* Top Bar Navigation Contract with Auth Controls */}
        <Header currentPage={currentPage} onNavigate={handleNavigate} />

        {/* Global Authentication Modal (Sign In / Sign Up / Forgot Password) */}
        <AuthModal />

        {/* Main Page Content */}
        <main id="main-content" className="flex-1 focus:outline-none">
          {currentPage === 'home' && (
            <HomePage
              onNavigate={handleNavigate}
              onSelectPrototype={handleSelectPrototype}
              onSelectArticle={handleSelectArticle}
            />
          )}
          {currentPage === 'about' && (
            <AboutPage onNavigate={handleNavigate} />
          )}
          {currentPage === 'prototypes' && (
            <PrototypesPage
              onNavigate={handleNavigate}
              selectedPrototypeId={selectedPrototypeId}
              onClearSelectedPrototype={() => setSelectedPrototypeId(null)}
            />
          )}
          {currentPage === 'journal' && (
            <JournalPage
              onNavigate={handleNavigate}
              selectedArticleId={selectedArticleId}
              onClearSelectedArticle={() => setSelectedArticleId(null)}
            />
          )}
          {currentPage === 'trend-watch' && (
            <TrendWatchPage onNavigate={handleNavigate} />
          )}
          {currentPage === 'contact' && (
            <ContactPage onNavigate={handleNavigate} />
          )}
          {currentPage === 'submit-idea' && (
            <SubmitIdeaPage onNavigate={handleNavigate} />
          )}
          {currentPage === 'my-submissions' && (
            <MySubmissionsPage onNavigate={handleNavigate} />
          )}
          {currentPage === 'admin' && (
            <AdminDashboardPage onNavigate={handleNavigate} />
          )}
        </main>

        {/* Editorial Footer */}
        <Footer onNavigate={handleNavigate} />
      </div>
    </AuthProvider>
  );
}
