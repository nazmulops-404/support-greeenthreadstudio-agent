import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Mail, Lock, User as UserIcon, AlertCircle, CheckCircle2, ArrowRight, RefreshCw, KeyRound, Sparkles } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    authModalOpen,
    authModalMode,
    closeAuthModal,
    setAuthModalMode,
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    sendPasswordReset,
    isConfigured,
  } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);

  if (!authModalOpen) return null;

  const resetForm = () => {
    setName('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setError(null);
    setResetSent(false);
  };

  const switchMode = (newMode: 'signin' | 'signup' | 'forgot') => {
    resetForm();
    setAuthModalMode(newMode);
  };

  const formatFirebaseError = (err: any): string => {
    if (!err) return 'An unexpected authentication error occurred.';
    const code = err.code || '';
    switch (code) {
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
      case 'auth/user-not-found':
        return 'Incorrect email or password. Please verify your details.';
      case 'auth/email-already-in-use':
        return 'An account already exists with this email address. Please sign in instead.';
      case 'auth/weak-password':
        return 'The password is too weak. Please use at least 6 characters.';
      case 'auth/invalid-email':
        return 'Please provide a valid email address.';
      case 'auth/popup-closed-by-user':
        return 'Google sign-in popup was closed before completion. Please try again.';
      case 'auth/popup-blocked':
        return 'Sign-in popup was blocked by your browser. Please allow popups for this site.';
      case 'auth/network-request-failed':
        return 'Network connection issue. Please check your internet connection.';
      case 'auth/too-many-requests':
        return 'Access temporarily disabled due to many failed attempts. Try again later or reset your password.';
      case 'auth/operation-not-allowed':
        return 'This sign-in provider is not enabled in Firebase Console. Please enable Email/Password or Google in Authentication > Sign-in method.';
      default:
        return err.message || 'Authentication failed. Please try again.';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }

    if (authModalMode === 'forgot') {
      try {
        setLoading(true);
        await sendPasswordReset(email);
        setResetSent(true);
      } catch (err: any) {
        setError(formatFirebaseError(err));
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    if (authModalMode === 'signup') {
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }

      try {
        setLoading(true);
        await signUpWithEmail(email, password, name);
        closeAuthModal();
        resetForm();
      } catch (err: any) {
        setError(formatFirebaseError(err));
      } finally {
        setLoading(false);
      }
      return;
    }

    // Sign in mode
    try {
      setLoading(true);
      await signInWithEmail(email, password);
      closeAuthModal();
      resetForm();
    } catch (err: any) {
      setError(formatFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    try {
      setGoogleLoading(true);
      await signInWithGoogle();
      closeAuthModal();
      resetForm();
    } catch (err: any) {
      setError(formatFirebaseError(err));
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1C1917]/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="bg-[#FBF9F5] border border-[#E5DFD5] rounded-lg max-w-md w-full shadow-2xl relative overflow-hidden">
        
        {/* Editorial Top Border Accent */}
        <div className="h-1.5 bg-gradient-to-r from-[#14532D] via-[#7B9B7B] to-[#14532D]" />

        {/* Modal Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-1.5 text-[#5C564E] hover:text-[#14532D] rounded-full hover:bg-[#F4EFE6] transition-colors cursor-pointer"
          aria-label="Close authentication modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Header */}
          <div className="space-y-1">
            <span className="text-[11px] font-semibold uppercase tracking-widest text-[#7B9B7B]">
              GreenThread Studio Account
            </span>
            <h2 id="auth-modal-title" className="font-serif text-3xl font-medium text-[#14532D]">
              {authModalMode === 'signin' && 'Sign In to Studio'}
              {authModalMode === 'signup' && 'Create Your Account'}
              {authModalMode === 'forgot' && 'Reset Password'}
            </h2>
            <p className="text-xs text-[#5C564E] leading-relaxed">
              {authModalMode === 'signin' && 'Access research notes, save prototype preferences, and submit material inquiries.'}
              {authModalMode === 'signup' && 'Join the GreenThread research community for open textile dispatches and prototype testing.'}
              {authModalMode === 'forgot' && 'Enter your account email to receive a password recovery link.'}
            </p>
          </div>

          {/* Missing Configuration Notice (if environment variables not yet provided) */}
          {!isConfigured && (
            <div className="p-3.5 bg-[#F4EFE6] border border-[#D5CEBF] rounded text-xs text-[#5C564E] space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-[#14532D]">
                <AlertCircle className="w-4 h-4 text-[#8C6D23] shrink-0" />
                <span>Firebase Configuration Notice</span>
              </div>
              <p className="leading-relaxed">
                Firebase environment variables are not yet detected. Add your <code className="bg-white px-1 py-0.5 rounded text-[11px] font-mono border border-[#E5DFD5]">VITE_FIREBASE_*</code> values to <code className="font-mono text-[11px]">.env</code> or your Vercel Project Settings to activate live authentication.
              </p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded flex items-start gap-2.5 text-xs text-red-800 leading-relaxed animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Reset Sent Success Notice */}
          {resetSent ? (
            <div className="p-5 bg-[#E8F0E8] border border-[#D5E3D5] rounded text-center space-y-3">
              <div className="w-10 h-10 mx-auto rounded-full bg-[#14532D] text-white flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="font-serif text-lg font-medium text-[#14532D]">Check Your Inbox</h4>
                <p className="text-xs text-[#5C564E]">
                  We sent a password reset link to <strong>{email}</strong>. Please follow the link in the email to choose a new password.
                </p>
              </div>
              <button
                onClick={() => switchMode('signin')}
                className="cursor-pointer text-xs font-semibold uppercase tracking-wider text-[#14532D] underline underline-offset-4"
              >
                Back to Sign In
              </button>
            </div>
          ) : (
            <>
              {/* Google Sign In Button (for signin & signup) */}
              {authModalMode !== 'forgot' && (
                <div className="space-y-4">
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    disabled={googleLoading || loading}
                    className="cursor-pointer w-full py-2.5 px-4 text-xs font-medium text-[#2D312E] bg-white hover:bg-[#F4EFE6] border border-[#E5DFD5] rounded shadow-xs flex items-center justify-center gap-3 transition-colors disabled:opacity-50"
                  >
                    {googleLoading ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-[#14532D]" />
                    ) : (
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.27 21.36 7.35 24 12 24z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.94 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                        />
                      </svg>
                    )}
                    <span>Continue with Google</span>
                  </button>

                  {/* Or Hairline Divider */}
                  <div className="relative flex items-center justify-center">
                    <div className="w-full border-t border-[#E5DFD5]" />
                    <span className="bg-[#FBF9F5] px-3 text-[11px] uppercase tracking-wider text-[#8C8275] absolute">
                      or with email
                    </span>
                  </div>
                </div>
              )}

              {/* Email / Password Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                
                {authModalMode === 'signup' && (
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Full Name <span className="text-[#8C8275] font-normal">(Optional)</span>
                    </label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 text-[#8C8275] absolute left-3 top-3 pointer-events-none" />
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Dr. Sabrina Ahmed"
                        className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                      />
                    </div>
                  </div>
                )}

                {/* Email Field */}
                <div className="space-y-1">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                    Email Address <span className="text-[#8C6D23]">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#8C8275] absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. sabrina@institution.edu"
                      className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                    />
                  </div>
                </div>

                {/* Password Field (for signin & signup) */}
                {authModalMode !== 'forgot' && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                        Password <span className="text-[#8C6D23]">*</span>
                      </label>
                      {authModalMode === 'signin' && (
                        <button
                          type="button"
                          onClick={() => switchMode('forgot')}
                          className="cursor-pointer text-[11px] text-[#5C564E] hover:text-[#14532D] underline"
                        >
                          Forgot password?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-[#8C8275] absolute left-3 top-3 pointer-events-none" />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                      />
                    </div>
                  </div>
                )}

                {/* Confirm Password Field (for signup) */}
                {authModalMode === 'signup' && (
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#14532D]">
                      Confirm Password <span className="text-[#8C6D23]">*</span>
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-[#8C8275] absolute left-3 top-3 pointer-events-none" />
                      <input
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-white rounded border border-[#E5DFD5] text-[#2D312E] focus:outline-none focus:border-[#14532D] transition-colors"
                      />
                    </div>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading || googleLoading}
                  className="cursor-pointer w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] disabled:opacity-60 rounded transition-all shadow-xs flex items-center justify-center gap-2 mt-2"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <span>
                        {authModalMode === 'signin' && 'Sign In'}
                        {authModalMode === 'signup' && 'Create Account'}
                        {authModalMode === 'forgot' && 'Send Recovery Email'}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </form>
            </>
          )}

          {/* Mode Switcher Links */}
          <div className="pt-3 border-t border-[#E5DFD5] text-center text-xs text-[#5C564E] space-y-1">
            {authModalMode === 'signin' && (
              <p>
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="cursor-pointer font-semibold text-[#14532D] hover:underline"
                >
                  Sign Up
                </button>
              </p>
            )}

            {authModalMode === 'signup' && (
              <p>
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signin')}
                  className="cursor-pointer font-semibold text-[#14532D] hover:underline"
                >
                  Sign In
                </button>
              </p>
            )}

            {authModalMode === 'forgot' && (
              <p>
                Remember your password?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signin')}
                  className="cursor-pointer font-semibold text-[#14532D] hover:underline"
                >
                  Return to Sign In
                </button>
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
