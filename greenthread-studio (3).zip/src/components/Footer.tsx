import React from 'react';
import { PageId } from '../types';
import { Mail, MapPin, Globe, ArrowUpRight, MessageSquare } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#F4EFE6] border-t border-[#E5DFD5] text-[#2D312E] mt-24">
      {/* Top Editorial Ribbon */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="/images/logo.jpg"
                alt="GreenThread Studio Inc. Logo"
                className="h-11 w-11 rounded-full object-contain bg-white border border-[#14532D]/20 p-0.5 shadow-xs"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/assets/aistudio/iZqx5jgZ2fFL5zTQa_i632ncu-ulOcxgsElkkvHaPM0-zlXKWbm-ewhveMp48DNkC8iMC2zvnG_YWOMj8m8TQ5zphbB7DNXcrJOSsls8pmUnNPtqWs_WuHD6PUdN5dKuII7zei2WTY85kv7gZ8A6Tg5AQDMH5DEEoVthqwvpoyUcVapHyU-IwM47zfDgOwSJ_4457485d.jpg';
                }}
              />
              <div className="font-serif text-2xl font-bold tracking-tight text-[#14532D] flex items-baseline gap-1.5">
                <span>GreenThread Studio</span>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#7B9B7B]">Inc.</span>
              </div>
            </div>
            <p className="font-serif italic text-lg text-[#14532D]/90">
              Thoughtful Textiles for Everyday Life.
            </p>
            <p className="text-sm text-[#5C564E] leading-relaxed max-w-md">
              An early-stage sustainable textile initiative based in Bangladesh. We explore natural fiber mechanics, indigenous jute-cotton blending, and pre-consumer cutting-room waste valorization through honest, rigorous prototyping.
            </p>

            <div className="pt-2 text-xs text-[#5C564E] space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#14532D] shrink-0" />
                <span>Dhaka, Bangladesh <span className="text-[#8C8275]">[Studio Location Placeholder]</span></span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#14532D] shrink-0" />
                <span>contact@greenthreadstudio.example <span className="text-[#8C8275]">[Contact Email]</span></span>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-[#14532D] shrink-0" />
                <span className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-medium text-[#14532D]">WhatsApp (Text Only):</span>
                  <a
                    href="https://wa.me/8801919863846?text=Hello%20GreenThread%20Studio%20Inc."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-mono text-[#14532D] hover:underline font-medium"
                    title="WhatsApp Text Inquiries Only"
                  >
                    +8801919863846
                  </a>
                  <span className="text-[10px] px-1.5 py-0.5 bg-[#E8F0E8] text-[#14532D] font-medium rounded border border-[#D5E3D5]">
                    WhatsApp chat only
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              Navigation
            </div>
            <ul className="space-y-2 text-sm text-[#5C564E]">
              <li>
                <button
                  onClick={() => handleNav('home')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  Home Overview
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('about')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  About Our Vision & Research
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('prototypes')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  Products & Prototypes
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('submit-idea')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left font-medium text-[#14532D]"
                >
                  Submit an Idea
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('my-submissions')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  My Submissions Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('journal')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  Journal & Engineering Notes
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('trend-watch')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  Textile Trend Watch
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('contact')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left"
                >
                  Contact & Sample Inquiry
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('admin')}
                  className="hover:text-[#14532D] transition-colors cursor-pointer text-left text-xs text-[#8C8275]"
                >
                  Admin Management
                </button>
              </li>
            </ul>
          </div>

          {/* Research & Transparency Statement */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-widest text-[#14532D]">
              Transparency Charter
            </div>
            <div className="p-4 bg-[#E8F0E8]/70 border border-[#D5E3D5] rounded text-xs text-[#2D312E] leading-relaxed space-y-2">
              <p>
                <strong>Prototype Disclosure:</strong> We do not publish speculative carbon offset statistics, fictitious customer numbers, or premature environmental claims.
              </p>
              <p className="text-[#5C564E]">
                All designs currently displayed are pilot prototypes under material stress and laundering evaluation in Dhaka.
              </p>
            </div>
            
            <div className="pt-2 flex items-center gap-4 text-xs text-[#5C564E]">
              <span className="text-[#8C8275]">[Social Media Placeholders]:</span>
              <a href="#contact" onClick={() => handleNav('contact')} className="hover:text-[#14532D] underline">LinkedIn</a>
              <span aria-hidden="true">·</span>
              <a href="#contact" onClick={() => handleNav('contact')} className="hover:text-[#14532D] underline">Instagram</a>
              <span aria-hidden="true">·</span>
              <a href="#contact" onClick={() => handleNav('contact')} className="hover:text-[#14532D] underline">GitHub / Research</a>
            </div>
          </div>

        </div>

        {/* Bottom Hairline & Legal Bar */}
        <div className="mt-12 pt-8 border-t border-[#E5DFD5] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5C564E]">
          <div>
            &copy; {new Date().getFullYear()} GreenThread Studio Inc. Based in Dhaka, Bangladesh. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Designed with anti-slop editorial rigor</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-[11px] text-[#8C8275]">React & TypeScript SPA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
