import React, { useState } from 'react';
import { Info, X } from 'lucide-react';

export const NoticeBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-[#14532D] text-[#F4EFE6] px-4 py-2.5 text-xs sm:text-sm border-b border-[#0D381E] transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <Info className="w-4 h-4 text-[#7B9B7B] shrink-0" />
          <p className="leading-snug">
            <strong className="font-semibold text-white">Early-Stage Studio Notice:</strong>{' '}
            GreenThread Studio is actively preparing our first product prototypes in Dhaka, Bangladesh. All concepts are in active development and not yet available for commercial purchase.
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-[#7B9B7B] hover:text-white p-1 transition-colors shrink-0 cursor-pointer"
          aria-label="Dismiss banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
