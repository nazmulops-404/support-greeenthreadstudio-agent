import React, { useState } from 'react';
import { Layers, Sparkles } from 'lucide-react';

interface TextileImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  fallbackTitle?: string;
  fallbackCategory?: string;
  aspectRatioClass?: string;
}

export const TextileImage: React.FC<TextileImageProps> = ({
  src,
  alt,
  fallbackTitle,
  fallbackCategory = 'Textile Prototype',
  aspectRatioClass = 'aspect-[4/3]',
  className = '',
  ...props
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (hasError) {
    return (
      <div
        className={`relative w-full ${aspectRatioClass} bg-[#F4EFE6] border border-[#E5DFD5] overflow-hidden flex flex-col items-center justify-center p-6 text-center select-none ${className}`}
        role="img"
        aria-label={alt}
      >
        {/* Subtle SVG weave texture background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#14532D_1px,transparent_1px)] [background-size:16px_16px]" />
        
        {/* Delicate inner hairline border */}
        <div className="absolute inset-3 border border-[#7B9B7B]/30 rounded-xs pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center gap-2 max-w-xs">
          <div className="w-10 h-10 rounded-full bg-[#E8F0E8] border border-[#D5E3D5] flex items-center justify-center text-[#14532D]">
            <Layers className="w-5 h-5" />
          </div>
          
          <div className="space-y-1">
            <span className="text-[10px] font-semibold uppercase tracking-widest text-[#7B9B7B]">
              {fallbackCategory}
            </span>
            <p className="font-serif text-lg font-medium text-[#14532D] leading-snug line-clamp-2">
              {fallbackTitle || alt}
            </p>
          </div>

          <p className="text-[11px] text-[#8C8275] italic pt-1">
            Tactile Handloom Weave Sample · Dhaka
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-full ${aspectRatioClass} overflow-hidden bg-[#EAE4D9] ${className}`}>
      {/* Loading placeholder skeleton */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-[#EAE4D9] animate-pulse flex items-center justify-center text-[#8C8275]">
          <Layers className="w-6 h-6 opacity-30" />
        </div>
      )}

      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        referrerPolicy="no-referrer"
        onLoad={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        className={`w-full h-full object-cover transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        {...props}
      />
    </div>
  );
};
