import React, { useState } from 'react';
import { PageId } from '../types';
import { useAuth } from '../context/AuthContext';
import { Menu, X, ArrowUpRight, User, LogOut, LogIn, UserPlus, Lightbulb, FileText, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAdmin, loading, openAuthModal, logout } = useAuth();

  const navItems: { id: PageId; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'prototypes', label: 'Prototypes' },
    { id: 'journal', label: 'Journal' },
    { id: 'trend-watch', label: 'Trend Watch' },
    { id: 'submit-idea', label: 'Submit Idea' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNav = (page: PageId) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const displayName = user?.displayName || user?.email?.split('@')[0] || 'Member';

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F5]/90 backdrop-blur-md border-b border-[#E5DFD5]">
      {/* 3-Zone Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-6 lg:gap-8">
        
        {/* Zone 1: Brand Wordmark with Official Logo */}
        <button
          onClick={() => handleNav('home')}
          className="text-left group cursor-pointer focus:outline-none shrink-0 flex items-center gap-2.5 sm:gap-3"
          aria-label="GreenThread Studio Inc. Homepage"
        >
          <img
            src="/images/logo.jpg"
            alt="GreenThread Studio Inc. Logo"
            className="h-9 w-9 sm:h-10 sm:w-10 rounded-full object-contain bg-white border border-[#14532D]/15 p-0.5 shadow-xs transition-transform group-hover:scale-105"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/assets/aistudio/iZqx5jgZ2fFL5zTQa_i632ncu-ulOcxgsElkkvHaPM0-zlXKWbm-ewhveMp48DNkC8iMC2zvnG_YWOMj8m8TQ5zphbB7DNXcrJOSsls8pmUnNPtqWs_WuHD6PUdN5dKuII7zei2WTY85kv7gZ8A6Tg5AQDMH5DEEoVthqwvpoyUcVapHyU-IwM47zfDgOwSJ_4457485d.jpg';
            }}
          />
          <div className="flex items-baseline gap-1.5">
            <span className="font-serif text-xl sm:text-2xl font-semibold tracking-tight text-[#14532D] group-hover:text-[#0D381E] transition-colors whitespace-nowrap">
              GreenThread Studio
            </span>
            <span className="text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-[#7B9B7B]">
              Inc.
            </span>
          </div>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-5 xl:gap-6 text-sm">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`cursor-pointer whitespace-nowrap transition-colors py-1 relative ${
                  isActive
                    ? 'text-[#14532D] font-semibold'
                    : 'text-[#5C564E] hover:text-[#14532D]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#14532D]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Authentication & Action Zone */}
        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          {!loading && (
            <>
              {user ? (
                /* Signed In User Controls */
                <div className="flex items-center gap-2">
                  {/* Admin Console Shortcut */}
                  {isAdmin && (
                    <button
                      onClick={() => handleNav('admin')}
                      className={`cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded border transition-colors ${
                        currentPage === 'admin'
                          ? 'bg-[#14532D] text-white border-[#14532D]'
                          : 'bg-[#F4EFE6] text-[#14532D] hover:bg-[#EAE4D9] border-[#D5CEBF]'
                      }`}
                      title="Admin Submission Management"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-[#7B9B7B]" />
                      <span>Admin</span>
                    </button>
                  )}

                  {/* My Submissions Dashboard Link */}
                  <button
                    onClick={() => handleNav('my-submissions')}
                    className={`cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded border transition-colors ${
                      currentPage === 'my-submissions'
                        ? 'bg-[#14532D] text-white border-[#14532D]'
                        : 'bg-[#F4EFE6] text-[#14532D] hover:bg-[#EAE4D9] border-[#E5DFD5]'
                    }`}
                    title="View My Submissions"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>My Ideas</span>
                  </button>

                  {/* User Profile Pill */}
                  <div
                    className="flex items-center gap-2 text-xs text-[#2D312E] bg-white px-2.5 py-1.5 rounded border border-[#E5DFD5] max-w-[160px]"
                    title={user.email || ''}
                  >
                    <div className="w-5 h-5 rounded-full bg-[#14532D] text-white flex items-center justify-center shrink-0">
                      {user.photoURL ? (
                        <img
                          src={user.photoURL}
                          alt={displayName}
                          className="w-full h-full rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <User className="w-3 h-3" />
                      )}
                    </div>
                    <span className="font-medium truncate text-[#14532D]">{displayName}</span>
                  </div>

                  {/* Logout Button */}
                  <button
                    onClick={() => logout()}
                    className="cursor-pointer inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#5C564E] hover:text-red-700 hover:bg-red-50 border border-[#E5DFD5] rounded transition-colors"
                    title="Log Out"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="sr-only md:not-sr-only">Log Out</span>
                  </button>
                </div>
              ) : (
                /* Signed Out: Sign In & Sign Up buttons */
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAuthModal('signin')}
                    className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] hover:text-[#0D381E] hover:bg-[#F4EFE6] rounded transition-colors whitespace-nowrap"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Sign In</span>
                  </button>

                  <button
                    onClick={() => openAuthModal('signup')}
                    className="cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded transition-all shadow-xs whitespace-nowrap"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              )}
            </>
          )}

          {/* Quick Idea CTA */}
          <button
            onClick={() => handleNav('submit-idea')}
            className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#E8F0E8] hover:bg-[#D5E3D5] rounded transition-colors whitespace-nowrap"
            title="Submit a Textile Concept"
          >
            <Lightbulb className="w-3.5 h-3.5 text-[#14532D]" />
            <span className="hidden xl:inline">Submit Idea</span>
          </button>
        </div>

        {/* Mobile menu hamburger toggle */}
        <div className="flex lg:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            className="p-2 text-[#2D312E] hover:text-[#14532D] focus:outline-none cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#E5DFD5] bg-[#F4EFE6] px-4 pt-3 pb-6 space-y-3">
          
          {/* User Status / Auth in Mobile Menu */}
          <div className="p-3 bg-white rounded border border-[#E5DFD5] space-y-2">
            {user ? (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 rounded-full bg-[#14532D] text-white flex items-center justify-center shrink-0">
                      {user.photoURL ? (
                        <img
                          src={user.photoURL}
                          alt={displayName}
                          className="w-full h-full rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <User className="w-4 h-4" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[#14532D] truncate">{displayName}</div>
                      <div className="text-[11px] text-[#8C8275] truncate">{user.email}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      logout();
                      setMobileMenuOpen(false);
                    }}
                    className="cursor-pointer inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-red-700 bg-red-50 hover:bg-red-100 rounded transition-colors shrink-0"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Log Out</span>
                  </button>
                </div>

                <div className="pt-2 border-t border-[#E5DFD5] flex items-center gap-2">
                  <button
                    onClick={() => handleNav('my-submissions')}
                    className="flex-1 py-1.5 px-2 text-center text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#F4EFE6] hover:bg-[#EAE4D9] rounded border border-[#E5DFD5]"
                  >
                    My Submissions
                  </button>
                  {isAdmin && (
                    <button
                      onClick={() => handleNav('admin')}
                      className="flex-1 py-1.5 px-2 text-center text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded shadow-2xs"
                    >
                      Admin Console
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    openAuthModal('signin');
                    setMobileMenuOpen(false);
                  }}
                  className="cursor-pointer py-2 px-3 text-center text-xs font-semibold uppercase tracking-wider text-[#14532D] bg-[#F4EFE6] hover:bg-[#EAE4D9] rounded border border-[#E5DFD5]"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    openAuthModal('signup');
                    setMobileMenuOpen(false);
                  }}
                  className="cursor-pointer py-2 px-3 text-center text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] hover:bg-[#0D381E] rounded shadow-xs"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>

          {/* Navigation Links */}
          <div className="space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full text-left px-3 py-2.5 text-base font-medium rounded transition-colors ${
                  currentPage === item.id
                    ? 'bg-[#E8F0E8] text-[#14532D] font-semibold'
                    : 'text-[#2D312E] hover:bg-[#EAE4D9]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-[#E5DFD5]">
            <button
              onClick={() => handleNav('prototypes')}
              className="w-full text-center py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#14532D] rounded"
            >
              Explore Prototypes
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
