import {
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  updateDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import { User } from 'firebase/auth';
import { db, handleFirestoreError, OperationType, isFirebaseConfigured } from '../lib/firebase';
import { IdeaSubmission, SubmissionCategory, SubmissionStatus } from '../types';

export interface SubmitIdeaInput {
  name: string;
  email: string;
  title: string;
  category: SubmissionCategory;
  description: string;
}

// Generate a cryptographically secure random claim token
function generateSecureClaimToken(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghijkmnopqrstuvwxyz';
  let token = 'GT-';
  const array = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(array);
    for (let i = 0; i < 16; i++) {
      token += chars[array[i] % chars.length];
    }
  } else {
    for (let i = 0; i < 16; i++) {
      token += chars[Math.floor(Math.random() * chars.length)];
    }
  }
  return token;
}

// Map Firestore document data to IdeaSubmission interface
function mapSubmission(id: string, data: any): IdeaSubmission {
  const createdAt = data.createdAt instanceof Timestamp
    ? data.createdAt.toDate().toISOString()
    : (data.createdAt || new Date().toISOString());

  const updatedAt = data.updatedAt instanceof Timestamp
    ? data.updatedAt.toDate().toISOString()
    : (data.updatedAt || new Date().toISOString());

  return {
    id,
    name: data.name || '',
    email: data.email || '',
    title: data.title || '',
    category: data.category || 'other',
    description: data.description || '',
    status: data.status || 'received',
    ownerId: data.ownerId || null,
    claimToken: data.claimToken || '',
    adminNotes: data.adminNotes || '',
    createdAt,
    updatedAt,
  };
}

export const submissionService = {
  /**
   * Submit a new textile idea (guest or authenticated)
   */
  async submitIdea(input: SubmitIdeaInput, user: User | null): Promise<{ id: string; claimToken: string }> {
    if (!db || !isFirebaseConfigured) {
      throw new Error(
        'Firebase Firestore is not configured. Please supply your VITE_FIREBASE_* environment variables in .env or Vercel.'
      );
    }

    const submissionsCol = collection(db, 'submissions');
    const newDocRef = doc(submissionsCol);
    const claimToken = generateSecureClaimToken();

    const payload = {
      name: input.name.trim(),
      email: input.email.trim().toLowerCase(),
      title: input.title.trim(),
      category: input.category,
      description: input.description.trim(),
      status: 'received',
      ownerId: user ? user.uid : null,
      claimToken: claimToken,
      adminNotes: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    try {
      await setDoc(newDocRef, payload);
      
      // Store local guest claim record in browser storage for user convenience
      try {
        const storedClaims = JSON.parse(localStorage.getItem('gt_guest_claims') || '[]');
        storedClaims.push({
          id: newDocRef.id,
          title: input.title.trim(),
          token: claimToken,
          email: input.email.trim().toLowerCase(),
          date: new Date().toISOString(),
        });
        localStorage.setItem('gt_guest_claims', JSON.stringify(storedClaims));
      } catch {
        // local storage non-critical
      }

      return {
        id: newDocRef.id,
        claimToken,
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'submissions');
      throw error;
    }
  },

  /**
   * Get all submissions owned by a specific authenticated user
   */
  async getUserSubmissions(userId: string): Promise<IdeaSubmission[]> {
    if (!db || !isFirebaseConfigured) return [];

    try {
      const q = query(
        collection(db, 'submissions'),
        where('ownerId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((docSnap) => mapSubmission(docSnap.id, docSnap.data()));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'submissions');
      return [];
    }
  },

  /**
   * Securely claim a guest submission using the claimToken and matching email
   */
  async claimGuestSubmission(claimToken: string, user: User): Promise<IdeaSubmission> {
    if (!db || !isFirebaseConfigured) {
      throw new Error('Firebase Firestore is not configured.');
    }
    if (!user.email) {
      throw new Error('Your user account must have an email to claim a submission.');
    }

    const cleanToken = claimToken.trim();
    if (!cleanToken) {
      throw new Error('Please enter a valid claim token.');
    }

    try {
      // Find submission by claimToken
      const q = query(
        collection(db, 'submissions'),
        where('claimToken', '==', cleanToken)
      );
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        throw new Error('No submission found matching this claim code. Please check the code.');
      }

      const docSnap = snapshot.docs[0];
      const data = docSnap.data();

      // Check if already claimed
      if (data.ownerId) {
        if (data.ownerId === user.uid) {
          throw new Error('This submission is already linked to your account.');
        }
        throw new Error('This submission has already been claimed by another registered account.');
      }

      // Check email matching constraint (prevents claiming arbitrary tokens)
      const submitterEmail = (data.email || '').toLowerCase().trim();
      const userEmail = user.email.toLowerCase().trim();

      if (submitterEmail !== userEmail) {
        throw new Error(
          `Security mismatch: This submission was filed under "${submitterEmail}". Your signed-in email is "${userEmail}". You can only claim submissions filed under your own verified email.`
        );
      }

      // Update ownerId to current user
      await updateDoc(docSnap.ref, {
        ownerId: user.uid,
        updatedAt: serverTimestamp(),
      });

      return mapSubmission(docSnap.id, {
        ...data,
        ownerId: user.uid,
        updatedAt: new Date(),
      });
    } catch (error) {
      if (error instanceof Error && error.message.includes('Security mismatch')) {
        throw error;
      }
      handleFirestoreError(error, OperationType.UPDATE, 'submissions');
      throw error;
    }
  },

  /**
   * Admin: List all submissions in the studio pipeline
   */
  async getAllSubmissionsAdmin(): Promise<IdeaSubmission[]> {
    if (!db || !isFirebaseConfigured) return [];

    try {
      const q = query(
        collection(db, 'submissions'),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((docSnap) => mapSubmission(docSnap.id, docSnap.data()));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'submissions');
      return [];
    }
  },

  /**
   * Admin: Update the status and internal assessment notes of a submission
   */
  async updateSubmissionStatusAdmin(
    submissionId: string,
    status: SubmissionStatus,
    adminNotes?: string
  ): Promise<void> {
    if (!db || !isFirebaseConfigured) {
      throw new Error('Firebase Firestore is not configured.');
    }

    try {
      const docRef = doc(db, 'submissions', submissionId);
      const updatePayload: Record<string, any> = {
        status,
        updatedAt: serverTimestamp(),
      };
      if (typeof adminNotes === 'string') {
        updatePayload.adminNotes = adminNotes.trim();
      }

      await updateDoc(docRef, updatePayload);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `submissions/${submissionId}`);
      throw error;
    }
  },
};
